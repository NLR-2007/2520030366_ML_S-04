# ================================================================
# SAGE-FJD — STEP 4
# STRUCTURAL/METADATA VIEW WITH CATBOOST
# FIVE GROUP-ISOLATED OOF MODELS
# ================================================================

from pathlib import Path
from datetime import datetime, timezone
import gc
import hashlib
import html
import json
import re
import shutil
import time

import numpy as np
import pandas as pd

from catboost import CatBoostClassifier
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score
)

from IPython.display import display


# ------------------------------------------------
# 1. Configuration
# ------------------------------------------------

SEED = 42

PROJECT_DIRECTORY = Path(
    "/kaggle/working/proposed_sage_fjd"
)

OOF_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_manifest.csv"
)

RAW_FEATURE_COLUMNS = [
    "title",
    "location",
    "department",
    "salary_range",
    "company_profile",
    "description",
    "requirements",
    "benefits",
    "telecommuting",
    "has_company_logo",
    "has_questions",
    "employment_type",
    "required_experience",
    "required_education",
    "industry",
    "function"
]

TEXT_FIELDS = [
    "title",
    "company_profile",
    "description",
    "requirements",
    "benefits"
]

MISSINGNESS_FIELDS = [
    "location",
    "department",
    "salary_range",
    "company_profile",
    "description",
    "requirements",
    "benefits",
    "employment_type",
    "required_experience",
    "required_education",
    "industry",
    "function"
]

if not OOF_MANIFEST_PATH.is_file():
    raise FileNotFoundError(
        "Step 2 OOF manifest was not found."
    )


# ------------------------------------------------
# 2. Locate dataset
# ------------------------------------------------

dataset_candidates = [
    Path(
        "/kaggle/input/datasets/shivamb/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    ),
    Path(
        "/kaggle/input/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    )
]

dataset_candidates.extend(
    Path("/kaggle/input").rglob(
        "fake_job_postings.csv"
    )
)

dataset_candidates = [
    path
    for path in dataset_candidates
    if path.is_file()
]

if not dataset_candidates:
    raise FileNotFoundError(
        "fake_job_postings.csv was not found."
    )

DATASET_PATH = dataset_candidates[0]


# ------------------------------------------------
# 3. Load and validate OOF manifest
# ------------------------------------------------

oof_manifest = pd.read_csv(
    OOF_MANIFEST_PATH
)

required_manifest_columns = [
    "source_row_index",
    "fraudulent",
    "campaign_group",
    "oof_fold",
    "source_split"
]

missing_manifest_columns = [
    column
    for column in required_manifest_columns
    if column not in oof_manifest.columns
]

if missing_manifest_columns:
    raise ValueError(
        "Missing OOF columns: "
        + ", ".join(missing_manifest_columns)
    )

if len(oof_manifest) != 12525:
    raise ValueError(
        "Expected 12,525 training rows."
    )

if int(oof_manifest["fraudulent"].sum()) != 609:
    raise ValueError(
        "Expected 609 fraudulent rows."
    )

if not (
    oof_manifest["source_split"]
    .astype(str)
    .str.lower()
    .eq("train")
    .all()
):
    raise ValueError(
        "Non-training rows exist in OOF manifest."
    )

crossing_campaigns = int(
    (
        oof_manifest
        .groupby("campaign_group")["oof_fold"]
        .nunique()
        > 1
    ).sum()
)

if crossing_campaigns != 0:
    raise ValueError(
        "Campaign groups cross OOF folds."
    )


# ------------------------------------------------
# 4. Load only retained training features
# ------------------------------------------------

wanted_source_rows = set(
    oof_manifest["source_row_index"]
    .astype(int)
    .tolist()
)

retained_chunks = []
row_cursor = 0

print("=" * 72)
print("SAGE-FJD STEP 4 — STRUCTURAL/METADATA OOF BRANCH")
print("=" * 72)
print("Dataset:", DATASET_PATH)
print("Loading leakage-safe training rows...")

for dataset_chunk in pd.read_csv(
    DATASET_PATH,
    usecols=RAW_FEATURE_COLUMNS,
    chunksize=2000
):
    chunk_rows = np.arange(
        row_cursor,
        row_cursor + len(dataset_chunk)
    )

    keep_mask = np.isin(
        chunk_rows,
        list(wanted_source_rows)
    )

    if keep_mask.any():
        retained = (
            dataset_chunk.loc[keep_mask]
            .copy()
            .reset_index(drop=True)
        )

        retained.insert(
            0,
            "source_row_index",
            chunk_rows[keep_mask]
        )

        retained_chunks.append(retained)

    row_cursor += len(dataset_chunk)

raw_training_data = pd.concat(
    retained_chunks,
    ignore_index=True
)

del retained_chunks
gc.collect()

training_data = (
    oof_manifest
    .merge(
        raw_training_data,
        on="source_row_index",
        how="left",
        validate="one_to_one"
    )
    .sort_values("source_row_index")
    .reset_index(drop=True)
)

if len(training_data) != 12525:
    raise ValueError(
        "Training feature count mismatch."
    )


# ------------------------------------------------
# 5. Feature-engineering helpers
# ------------------------------------------------

def missing_mask(series):
    text = (
        series
        .fillna("")
        .astype(str)
        .str.strip()
    )

    return text.eq("")


def clean_plain_text(series):
    cleaned = (
        series
        .fillna("")
        .astype(str)
        .map(html.unescape)
    )

    cleaned = cleaned.str.replace(
        r"<[^>]+>",
        " ",
        regex=True
    )

    cleaned = cleaned.str.replace(
        r"[\r\n\t]+",
        " ",
        regex=True
    )

    cleaned = cleaned.str.replace(
        r"\s+",
        " ",
        regex=True
    )

    return cleaned.str.strip()


def parse_salary_numbers(value):
    if pd.isna(value):
        return []

    text = str(value).strip()

    if not text:
        return []

    number_strings = re.findall(
        r"\d[\d,]*(?:\.\d+)?",
        text
    )

    parsed_numbers = []

    for number_string in number_strings:
        try:
            parsed_numbers.append(
                float(
                    number_string.replace(",", "")
                )
            )
        except ValueError:
            continue

    return parsed_numbers


# ------------------------------------------------
# 6. Build metadata feature table
# ------------------------------------------------

metadata_features = pd.DataFrame(
    index=training_data.index
)

# Basic binary fields
for binary_field in [
    "telecommuting",
    "has_company_logo",
    "has_questions"
]:
    metadata_features[binary_field] = (
        pd.to_numeric(
            training_data[binary_field],
            errors="coerce"
        )
        .fillna(0)
        .clip(0, 1)
        .astype(np.float32)
    )

# Missingness indicators
missing_feature_names = []

for field in MISSINGNESS_FIELDS:
    feature_name = f"{field}_missing"

    metadata_features[feature_name] = (
        missing_mask(
            training_data[field]
        )
        .astype(np.float32)
    )

    missing_feature_names.append(feature_name)

metadata_features["total_missing_fields"] = (
    metadata_features[
        missing_feature_names
    ].sum(axis=1)
    .astype(np.float32)
)

# Text length and structure features
plain_text_fields = {}

for field in TEXT_FIELDS:
    plain_text = clean_plain_text(
        training_data[field]
    )

    plain_text_fields[field] = plain_text

    metadata_features[
        f"{field}_character_count"
    ] = (
        plain_text.str.len()
        .astype(np.float32)
    )

    metadata_features[
        f"{field}_word_count"
    ] = (
        plain_text.str.count(
            r"\b\w+\b"
        )
        .astype(np.float32)
    )

    metadata_features[
        f"{field}_sentence_count"
    ] = (
        plain_text.str.count(
            r"[.!?]+"
        )
        .astype(np.float32)
    )

# Combined text for risk-language signals
combined_plain_text = pd.Series(
    "",
    index=training_data.index,
    dtype="object"
)

combined_raw_text = pd.Series(
    "",
    index=training_data.index,
    dtype="object"
)

for field in TEXT_FIELDS:
    combined_plain_text = (
        combined_plain_text
        + " "
        + plain_text_fields[field]
    )

    combined_raw_text = (
        combined_raw_text
        + " "
        + training_data[field]
        .fillna("")
        .astype(str)
    )

combined_plain_text = (
    combined_plain_text
    .str.strip()
)

combined_lower_text = (
    combined_plain_text
    .str.lower()
)

# Character and punctuation signals
metadata_features["digit_count"] = (
    combined_plain_text
    .str.count(r"\d")
    .astype(np.float32)
)

metadata_features["uppercase_count"] = (
    combined_raw_text
    .map(
        lambda text: sum(
            character.isupper()
            for character in text
        )
    )
    .astype(np.float32)
)

alphabetic_count = (
    combined_raw_text
    .map(
        lambda text: sum(
            character.isalpha()
            for character in text
        )
    )
    .astype(np.float32)
)

metadata_features["uppercase_ratio"] = (
    metadata_features["uppercase_count"]
    / alphabetic_count.clip(lower=1)
).astype(np.float32)

metadata_features["exclamation_count"] = (
    combined_raw_text
    .str.count(r"!")
    .astype(np.float32)
)

metadata_features["question_mark_count"] = (
    combined_raw_text
    .str.count(r"\?")
    .astype(np.float32)
)

metadata_features["url_count"] = (
    combined_lower_text
    .str.count(
        r"(?:https?://|www\.)"
    )
    .astype(np.float32)
)

metadata_features["email_count"] = (
    combined_lower_text
    .str.count(
        r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b"
    )
    .astype(np.float32)
)

metadata_features["phone_like_count"] = (
    combined_plain_text
    .str.count(
        r"\b(?:\+?\d[\d\s().-]{7,}\d)\b"
    )
    .astype(np.float32)
)

# Fraud-language signals
metadata_features["money_language"] = (
    combined_lower_text
    .str.contains(
        r"\b(?:earn|earning|income|money|cash|"
        r"salary|payment|commission|bonus|"
        r"weekly pay|daily pay|per hour)\b",
        regex=True
    )
    .astype(np.float32)
)

metadata_features[
    "work_from_home_language"
] = (
    combined_lower_text
    .str.contains(
        r"\b(?:work from home|work-at-home|"
        r"home based|remote income)\b",
        regex=True
    )
    .astype(np.float32)
)

metadata_features[
    "no_experience_language"
] = (
    combined_lower_text
    .str.contains(
        r"\b(?:no experience|experience not required|"
        r"no prior experience|without experience)\b",
        regex=True
    )
    .astype(np.float32)
)

metadata_features["whatsapp_telegram"] = (
    combined_lower_text
    .str.contains(
        r"\b(?:whatsapp|telegram)\b",
        regex=True
    )
    .astype(np.float32)
)

metadata_features["excessive_uppercase"] = (
    (
        metadata_features["uppercase_ratio"]
        >= 0.60
    )
    & (
        metadata_features["uppercase_count"]
        >= 20
    )
).astype(np.float32)

# Salary-derived features
salary_number_lists = (
    training_data["salary_range"]
    .map(parse_salary_numbers)
)

salary_minimum = salary_number_lists.map(
    lambda values: (
        min(values)
        if len(values) >= 2
        else 0.0
    )
)

salary_maximum = salary_number_lists.map(
    lambda values: (
        max(values)
        if len(values) >= 2
        else 0.0
    )
)

salary_width = (
    salary_maximum
    - salary_minimum
).clip(lower=0)

metadata_features["salary_minimum_log"] = (
    np.log1p(salary_minimum)
    .astype(np.float32)
)

metadata_features["salary_maximum_log"] = (
    np.log1p(salary_maximum)
    .astype(np.float32)
)

metadata_features["salary_width_log"] = (
    np.log1p(salary_width)
    .astype(np.float32)
)

salary_status = pd.Series(
    "Provided but unparsed",
    index=training_data.index
)

salary_status.loc[
    missing_mask(
        training_data["salary_range"]
    )
] = "Missing"

salary_status.loc[
    salary_number_lists.map(len) >= 2
] = "Valid numeric range"

# Categorical features
location_text = (
    training_data["location"]
    .fillna("")
    .astype(str)
    .str.strip()
)

country = (
    location_text
    .str.split(
        pat=",",
        n=1,
        expand=True
    )[0]
    .str.strip()
    .replace("", "Missing")
)

categorical_data = pd.DataFrame({
    "country": country,
    "location": location_text.replace(
        "",
        "Missing"
    ),
    "department": training_data[
        "department"
    ],
    "employment_type": training_data[
        "employment_type"
    ],
    "required_experience": training_data[
        "required_experience"
    ],
    "required_education": training_data[
        "required_education"
    ],
    "industry": training_data[
        "industry"
    ],
    "function": training_data[
        "function"
    ],
    "salary_status": salary_status
})

for column in categorical_data.columns:
    categorical_data[column] = (
        categorical_data[column]
        .fillna("Missing")
        .astype(str)
        .str.strip()
        .replace("", "Missing")
    )

categorical_feature_names = (
    categorical_data.columns.tolist()
)

numerical_feature_names = (
    metadata_features.columns.tolist()
)

model_features = pd.concat(
    [
        categorical_data,
        metadata_features
    ],
    axis=1
)

if len(categorical_feature_names) != 9:
    raise ValueError(
        "Expected 9 categorical features."
    )

if len(numerical_feature_names) != 47:
    raise ValueError(
        "Expected 47 numerical features, "
        f"found {len(numerical_feature_names)}."
    )

if model_features.shape != (12525, 56):
    raise ValueError(
        "Expected metadata shape (12525, 56), "
        f"found {model_features.shape}."
    )

if model_features[
    numerical_feature_names
].isna().any().any():
    raise ValueError(
        "Numerical metadata contains missing values."
    )

print("\nMetadata shape:", model_features.shape)
print(
    "Categorical features:",
    len(categorical_feature_names)
)
print(
    "Numerical features:",
    len(numerical_feature_names)
)
print("Validation/test rows retained: 0")


# ------------------------------------------------
# 7. Metric helpers
# ------------------------------------------------

def evaluate_scores(
    labels,
    probabilities,
    threshold
):
    predictions = (
        probabilities >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        labels,
        predictions,
        labels=[0, 1]
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "Threshold": float(threshold),
        "Accuracy": accuracy_score(
            labels,
            predictions
        ),
        "Precision": precision_score(
            labels,
            predictions,
            zero_division=0
        ),
        "Recall": recall_score(
            labels,
            predictions,
            zero_division=0
        ),
        "F1": f1_score(
            labels,
            predictions,
            zero_division=0
        ),
        "Specificity": specificity,
        "Balanced_Accuracy":
            balanced_accuracy_score(
                labels,
                predictions
            ),
        "PR_AUC": average_precision_score(
            labels,
            probabilities
        ),
        "ROC_AUC": roc_auc_score(
            labels,
            probabilities
        ),
        "MCC": matthews_corrcoef(
            labels,
            predictions
        ),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp)
    }


def find_best_threshold(
    labels,
    probabilities,
    minimum_precision=None
):
    precision_values, recall_values, thresholds = (
        precision_recall_curve(
            labels,
            probabilities
        )
    )

    precision_values = precision_values[:-1]
    recall_values = recall_values[:-1]

    f1_values = (
        2
        * precision_values
        * recall_values
        / (
            precision_values
            + recall_values
            + 1e-12
        )
    )

    valid_mask = np.isfinite(f1_values)

    if minimum_precision is not None:
        valid_mask &= (
            precision_values
            >= minimum_precision
        )

    candidate_f1 = np.where(
        valid_mask,
        f1_values,
        -1.0
    )

    best_index = int(
        np.argmax(candidate_f1)
    )

    return float(thresholds[best_index])


# ------------------------------------------------
# 8. Group-isolated outer OOF training
# ------------------------------------------------

labels = (
    training_data["fraudulent"]
    .astype(int)
    .to_numpy()
)

fold_assignments = (
    training_data["oof_fold"]
    .astype(int)
    .to_numpy()
)

groups = (
    training_data["campaign_group"]
    .astype(str)
    .to_numpy()
)

oof_probabilities = np.full(
    len(training_data),
    np.nan,
    dtype=np.float64
)

fold_metric_rows = []

total_start_time = time.perf_counter()

for fold_number in [1, 2, 3, 4, 5]:

    print("\n" + "=" * 72)
    print(
        f"METADATA OOF TRAINING — "
        f"FOLD {fold_number}/5"
    )
    print("=" * 72)

    fold_start_time = time.perf_counter()

    outer_holdout_mask = (
        fold_assignments == fold_number
    )

    outer_training_mask = (
        ~outer_holdout_mask
    )

    outer_training_positions = np.where(
        outer_training_mask
    )[0]

    outer_holdout_positions = np.where(
        outer_holdout_mask
    )[0]

    if (
        set(groups[outer_training_positions])
        & set(groups[outer_holdout_positions])
    ):
        raise ValueError(
            "Outer campaign leakage detected."
        )

    outer_training_labels = labels[
        outer_training_positions
    ]

    outer_training_groups = groups[
        outer_training_positions
    ]

    # Inner group-safe split only for iteration selection
    inner_splitter = StratifiedGroupKFold(
        n_splits=4,
        shuffle=True,
        random_state=SEED + fold_number
    )

    inner_candidates = list(
        inner_splitter.split(
            np.zeros(
                (
                    len(outer_training_positions),
                    1
                )
            ),
            outer_training_labels,
            outer_training_groups
        )
    )

    overall_inner_rate = (
        outer_training_labels.mean()
    )

    def inner_split_score(split_pair):
        _, validation_positions = split_pair

        validation_labels = (
            outer_training_labels[
                validation_positions
            ]
        )

        return (
            abs(
                validation_labels.mean()
                - overall_inner_rate
            )
            + 0.10
            * abs(
                len(validation_positions)
                / len(outer_training_labels)
                - 0.25
            )
        )

    inner_training_local, inner_validation_local = min(
        inner_candidates,
        key=inner_split_score
    )

    inner_training_positions = (
        outer_training_positions[
            inner_training_local
        ]
    )

    inner_validation_positions = (
        outer_training_positions[
            inner_validation_local
        ]
    )

    inner_labels = labels[
        inner_training_positions
    ]

    inner_negative_count = int(
        (inner_labels == 0).sum()
    )

    inner_positive_count = int(
        (inner_labels == 1).sum()
    )

    inner_positive_weight = float(
        np.sqrt(
            inner_negative_count
            / max(inner_positive_count, 1)
        )
    )

    tuning_model = CatBoostClassifier(
        iterations=1200,
        depth=7,
        learning_rate=0.04,
        loss_function="Logloss",
        eval_metric="AUC",
        class_weights=[
            1.0,
            inner_positive_weight
        ],
        l2_leaf_reg=6.0,
        random_strength=0.5,
        bootstrap_type="Bernoulli",
        subsample=0.85,
        random_seed=SEED + fold_number,
        allow_writing_files=False,
        thread_count=-1,
        verbose=False
    )

    tuning_model.fit(
        model_features.iloc[
            inner_training_positions
        ],
        labels[inner_training_positions],
        cat_features=categorical_feature_names,
        eval_set=(
            model_features.iloc[
                inner_validation_positions
            ],
            labels[inner_validation_positions]
        ),
        early_stopping_rounds=100,
        verbose=False
    )

    best_iteration = (
        tuning_model.get_best_iteration()
    )

    if best_iteration is None or best_iteration < 0:
        best_iteration = 1199

    final_iterations = max(
        20,
        int(best_iteration) + 1
    )

    del tuning_model
    gc.collect()

    # Refit using every outer-training row
    outer_negative_count = int(
        (outer_training_labels == 0).sum()
    )

    outer_positive_count = int(
        (outer_training_labels == 1).sum()
    )

    outer_positive_weight = float(
        np.sqrt(
            outer_negative_count
            / max(outer_positive_count, 1)
        )
    )

    metadata_model = CatBoostClassifier(
        iterations=final_iterations,
        depth=7,
        learning_rate=0.04,
        loss_function="Logloss",
        eval_metric="AUC",
        class_weights=[
            1.0,
            outer_positive_weight
        ],
        l2_leaf_reg=6.0,
        random_strength=0.5,
        bootstrap_type="Bernoulli",
        subsample=0.85,
        random_seed=SEED + fold_number,
        allow_writing_files=False,
        thread_count=-1,
        verbose=False
    )

    metadata_model.fit(
        model_features.iloc[
            outer_training_positions
        ],
        labels[outer_training_positions],
        cat_features=categorical_feature_names,
        verbose=False
    )

    holdout_probabilities = (
        metadata_model.predict_proba(
            model_features.iloc[
                outer_holdout_positions
            ]
        )[:, 1]
    )

    oof_probabilities[
        outer_holdout_positions
    ] = holdout_probabilities

    fold_metrics = evaluate_scores(
        labels[outer_holdout_positions],
        holdout_probabilities,
        threshold=0.5
    )

    fold_time_seconds = (
        time.perf_counter()
        - fold_start_time
    )

    fold_metric_rows.append({
        "OOF_Fold": fold_number,
        "Training_Rows": len(
            outer_training_positions
        ),
        "Holdout_Rows": len(
            outer_holdout_positions
        ),
        "Holdout_Fraudulent": int(
            labels[
                outer_holdout_positions
            ].sum()
        ),
        "Selected_Iterations":
            final_iterations,
        "Positive_Class_Weight":
            outer_positive_weight,
        "PR_AUC": fold_metrics["PR_AUC"],
        "ROC_AUC": fold_metrics["ROC_AUC"],
        "Precision_at_0_5":
            fold_metrics["Precision"],
        "Recall_at_0_5":
            fold_metrics["Recall"],
        "F1_at_0_5":
            fold_metrics["F1"],
        "MCC_at_0_5":
            fold_metrics["MCC"],
        "Training_Time_Seconds":
            fold_time_seconds,
        "Crossing_Campaign_Groups": 0
    })

    print(
        "Selected iterations:",
        final_iterations
    )
    print(
        "PR-AUC:",
        round(fold_metrics["PR_AUC"], 4)
    )
    print(
        "F1 at threshold 0.5:",
        round(fold_metrics["F1"], 4)
    )
    print(
        "Fold time:",
        round(fold_time_seconds, 2),
        "seconds"
    )

    del metadata_model
    gc.collect()

if np.isnan(oof_probabilities).any():
    raise ValueError(
        "Some rows have no metadata OOF prediction."
    )

total_training_seconds = (
    time.perf_counter()
    - total_start_time
)


# ------------------------------------------------
# 9. Pooled OOF metrics
# ------------------------------------------------

best_f1_threshold = find_best_threshold(
    labels,
    oof_probabilities
)

precision_guardrail_threshold = (
    find_best_threshold(
        labels,
        oof_probabilities,
        minimum_precision=0.90
    )
)

pooled_rows = []

for threshold_type, threshold in [
    ("Default 0.50", 0.50),
    (
        "OOF F1 Optimized",
        best_f1_threshold
    ),
    (
        "Precision >= 0.90",
        precision_guardrail_threshold
    )
]:
    metric_row = evaluate_scores(
        labels,
        oof_probabilities,
        threshold
    )

    metric_row[
        "Threshold_Type"
    ] = threshold_type

    pooled_rows.append(metric_row)

pooled_metrics = pd.DataFrame(
    pooled_rows
)[
    [
        "Threshold_Type",
        "Threshold",
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "Specificity",
        "Balanced_Accuracy",
        "PR_AUC",
        "ROC_AUC",
        "MCC",
        "TN",
        "FP",
        "FN",
        "TP"
    ]
]

fold_metrics_table = pd.DataFrame(
    fold_metric_rows
)


# ------------------------------------------------
# 10. Save Step 4 artifacts
# ------------------------------------------------

metadata_predictions = oof_manifest.copy()

metadata_predictions[
    "metadata_probability"
] = oof_probabilities

prediction_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_oof_predictions.csv"
)

fold_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_oof_fold_metrics.csv"
)

pooled_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_oof_pooled_metrics.csv"
)

feature_manifest_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_feature_manifest.csv"
)

configuration_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_configuration.json"
)

metadata_predictions.to_csv(
    prediction_path,
    index=False
)

fold_metrics_table.to_csv(
    fold_metrics_path,
    index=False
)

pooled_metrics.to_csv(
    pooled_metrics_path,
    index=False
)

feature_manifest = pd.DataFrame({
    "Feature": (
        categorical_feature_names
        + numerical_feature_names
    ),
    "Feature_Type": (
        ["Categorical"]
        * len(categorical_feature_names)
        + ["Numerical"]
        * len(numerical_feature_names)
    )
})

feature_manifest.to_csv(
    feature_manifest_path,
    index=False
)


def file_sha256(file_path):
    checksum = hashlib.sha256()

    with open(file_path, "rb") as file_handle:
        for block in iter(
            lambda: file_handle.read(
                1024 * 1024
            ),
            b""
        ):
            checksum.update(block)

    return checksum.hexdigest()


configuration = {
    "created_utc":
        datetime.now(timezone.utc).isoformat(),
    "experiment":
        "SAGE-FJD",
    "step":
        4,
    "view":
        "Structural/Metadata",
    "categorical_features":
        categorical_feature_names,
    "numerical_features":
        numerical_feature_names,
    "feature_count":
        model_features.shape[1],
    "outer_oof_folds":
        5,
    "inner_group_safe_iteration_selection":
        True,
    "class_weight_method":
        "square_root_imbalance_ratio",
    "pooled_oof_pr_auc":
        float(
            average_precision_score(
                labels,
                oof_probabilities
            )
        ),
    "best_oof_f1_threshold":
        best_f1_threshold,
    "training_seconds":
        total_training_seconds,
    "campaign_overlap":
        0,
    "validation_rows_used":
        0,
    "test_rows_used":
        0,
    "prediction_sha256":
        file_sha256(prediction_path)
}

with open(
    configuration_path,
    "w",
    encoding="utf-8"
) as configuration_file:
    json.dump(
        configuration,
        configuration_file,
        indent=2
    )

checkpoint_zip = Path(
    shutil.make_archive(
        "/kaggle/working/"
        "sage_fjd_step_04_checkpoint",
        "zip",
        root_dir=PROJECT_DIRECTORY
    )
)


# ------------------------------------------------
# 11. Display results
# ------------------------------------------------

print("\nMETADATA OOF FOLD RESULTS")
display(
    fold_metrics_table.round(4)
)

print("\nPOOLED METADATA OOF RESULTS")
display(
    pooled_metrics.round(4)
)

print("\n" + "=" * 72)
print("SAGE-FJD PROPOSED MODEL STEP 4 COMPLETED")
print("=" * 72)
print(
    "Total time:",
    round(total_training_seconds / 60, 2),
    "minutes"
)
print(
    "Pooled OOF PR-AUC:",
    round(
        average_precision_score(
            labels,
            oof_probabilities
        ),
        4
    )
)
print("Metadata features:", model_features.shape[1])
print("Campaign overlap: 0")
print("Validation rows used: 0")
print("Test rows used: 0")
print("Predictions:", prediction_path)
print("Checkpoint ZIP:", checkpoint_zip)
print("Next step: section-aware semantic OOF branch.")
print("=" * 72)