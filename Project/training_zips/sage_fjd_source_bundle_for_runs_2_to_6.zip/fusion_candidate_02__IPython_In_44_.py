# ================================================================
# SAGE-FJD — STEP 8
# FREEZE ARCHITECTURE AND PREPARE LOCKED VALIDATION
# NO MODEL TRAINING OR VALIDATION EVALUATION
# ================================================================

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import shutil

import numpy as np
import pandas as pd
from IPython.display import display


# ------------------------------------------------
# 1. Paths
# ------------------------------------------------

PROJECT_DIRECTORY = Path(
    "/kaggle/working/proposed_sage_fjd"
)

OOF_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_manifest.csv"
)

OOF_COMPARISON_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_branch_comparison.csv"
)

FUSION_METRICS_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_oof_pooled_metrics.csv"
)

METADATA_FOLD_METRICS_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_oof_fold_metrics.csv"
)

FREEZE_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_architecture_freeze.json"
)

FINAL_TRAIN_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_final_training_manifest.csv"
)

VALIDATION_FEATURE_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_locked_validation_manifest.csv"
)

SEALED_VALIDATION_LABELS_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_validation_labels_sealed.csv"
)

VALIDATION_AUDIT_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_validation_preparation_audit.json"
)


# ------------------------------------------------
# 2. Helpers
# ------------------------------------------------

def normalize_column_name(column_name):
    return re.sub(
        r"[^a-z0-9]+",
        "_",
        str(column_name).strip().lower()
    ).strip("_")


def find_column(columns, candidates):
    column_lookup = {
        normalize_column_name(column): column
        for column in columns
    }

    for candidate in candidates:
        normalized_candidate = (
            normalize_column_name(candidate)
        )

        if normalized_candidate in column_lookup:
            return column_lookup[
                normalized_candidate
            ]

    return None


def file_sha256(file_path):
    checksum = hashlib.sha256()

    with open(file_path, "rb") as file_handle:
        for block in iter(
            lambda: file_handle.read(
                1024 * 1024
            ),
            b""
        ):
            checksum.update(block)

    return checksum.hexdigest()


# ------------------------------------------------
# 3. Locate locked split manifest
# ------------------------------------------------

manifest_candidates = [
    Path(
        "/kaggle/working/"
        "emscad_split_manifest.csv"
    )
]

manifest_candidates.extend(
    Path("/kaggle/input").rglob(
        "emscad_split_manifest.csv"
    )
)

manifest_candidates = [
    path
    for path in manifest_candidates
    if path.is_file()
]

if not manifest_candidates:
    raise FileNotFoundError(
        "Locked EMSCAD split manifest "
        "was not found."
    )

LOCKED_MANIFEST_PATH = (
    manifest_candidates[0]
)


# ------------------------------------------------
# 4. Verify required Step 1–7 artifacts
# ------------------------------------------------

required_artifacts = [
    OOF_MANIFEST_PATH,
    OOF_COMPARISON_PATH,
    FUSION_METRICS_PATH,
    METADATA_FOLD_METRICS_PATH,
    PROJECT_DIRECTORY
    / "sage_fjd_lexical_configuration.json",
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_configuration.json",
    PROJECT_DIRECTORY
    / "sage_fjd_semantic_configuration.json",
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_configuration.json",
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_configuration.json",
    PROJECT_DIRECTORY
    / "sage_fjd_lexical_oof_predictions.csv",
    PROJECT_DIRECTORY
    / "sage_fjd_metadata_oof_predictions.csv",
    PROJECT_DIRECTORY
    / "sage_fjd_semantic_oof_predictions.csv",
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_oof_predictions.csv",
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_oof_predictions.csv"
]

missing_artifacts = [
    str(path)
    for path in required_artifacts
    if not path.is_file()
]

if missing_artifacts:
    raise FileNotFoundError(
        "Required artifacts are missing:\n"
        + "\n".join(missing_artifacts)
    )


# ------------------------------------------------
# 5. Load split metadata WITHOUT target labels
# ------------------------------------------------

manifest_header = pd.read_csv(
    LOCKED_MANIFEST_PATH,
    nrows=0
)

manifest_columns = (
    manifest_header.columns.tolist()
)

split_column = find_column(
    manifest_columns,
    [
        "leakage_safe_split",
        "leakage-safe_split",
        "safe_split"
    ]
)

campaign_column = find_column(
    manifest_columns,
    [
        "campaign_group",
        "campaign_group_id",
        "campaign_id"
    ]
)

target_column = find_column(
    manifest_columns,
    [
        "fraudulent",
        "target",
        "label"
    ]
)

job_id_column = find_column(
    manifest_columns,
    [
        "job_id",
        "jobid"
    ]
)

source_index_column = find_column(
    manifest_columns,
    [
        "source_row_index",
        "row_index",
        "original_index",
        "dataset_index",
        "unnamed_0"
    ]
)

if split_column is None:
    raise ValueError(
        "Leakage-safe split column is missing."
    )

if campaign_column is None:
    raise ValueError(
        "Campaign group column is missing."
    )

if target_column is None:
    raise ValueError(
        "Target column is missing."
    )

metadata_columns = [
    split_column,
    campaign_column
]

if job_id_column is not None:
    metadata_columns.append(
        job_id_column
    )

if source_index_column is not None:
    metadata_columns.append(
        source_index_column
    )

split_metadata = pd.read_csv(
    LOCKED_MANIFEST_PATH,
    usecols=list(dict.fromkeys(metadata_columns))
)


# ------------------------------------------------
# 6. Create stable source-row identifier
# ------------------------------------------------

if source_index_column is not None:

    source_indices = pd.to_numeric(
        split_metadata[source_index_column],
        errors="coerce"
    )

    if source_indices.isna().any():
        raise ValueError(
            "Invalid source-row identifiers."
        )

    source_indices = (
        source_indices.astype(int)
    )

    if (
        source_indices.min() == 1
        and source_indices.max()
            == len(split_metadata)
        and source_indices.nunique()
            == len(split_metadata)
    ):
        source_indices = (
            source_indices - 1
        )

else:
    source_indices = pd.Series(
        np.arange(len(split_metadata)),
        index=split_metadata.index
    )

if source_indices.duplicated().any():
    raise ValueError(
        "Source-row identifiers are duplicated."
    )

split_metadata[
    "source_row_index"
] = source_indices.to_numpy()

split_metadata[
    "source_split"
] = (
    split_metadata[split_column]
    .astype(str)
    .str.strip()
    .str.lower()
    .str.replace("-", "_", regex=False)
)

valid_split_names = {
    "train",
    "validation",
    "test"
}

if not set(
    split_metadata["source_split"].unique()
).issubset(valid_split_names):
    raise ValueError(
        "Unexpected split names were found."
    )

campaign_values = (
    split_metadata[campaign_column]
    .astype("string")
    .str.strip()
)

invalid_campaign = (
    campaign_values.isna()
    | campaign_values.eq("")
    | campaign_values.str.lower().isin(
        ["nan", "none", "null", "<na>"]
    ).fillna(True)
)

campaign_values = (
    campaign_values.astype(object)
)

campaign_values.loc[invalid_campaign] = (
    "__singleton_row_"
    + split_metadata.loc[
        invalid_campaign,
        "source_row_index"
    ].astype(str)
)

split_metadata[
    "campaign_group"
] = campaign_values.astype(str)


# ------------------------------------------------
# 7. Verify locked split structure
# ------------------------------------------------

split_counts = (
    split_metadata[
        "source_split"
    ].value_counts()
)

expected_split_counts = {
    "train": 12525,
    "validation": 2675,
    "test": 2680
}

for split_name, expected_count in (
    expected_split_counts.items()
):
    actual_count = int(
        split_counts.get(split_name, 0)
    )

    if actual_count != expected_count:
        raise ValueError(
            f"{split_name} expected "
            f"{expected_count} rows, "
            f"found {actual_count}."
        )

campaign_split_counts = (
    split_metadata
    .groupby("campaign_group")[
        "source_split"
    ]
    .nunique()
)

crossing_locked_groups = int(
    (campaign_split_counts > 1).sum()
)

if crossing_locked_groups != 0:
    raise ValueError(
        "Campaign groups cross locked splits."
    )

training_metadata = (
    split_metadata[
        split_metadata["source_split"]
        == "train"
    ]
    .copy()
)

validation_metadata = (
    split_metadata[
        split_metadata["source_split"]
        == "validation"
    ]
    .copy()
)

test_metadata = (
    split_metadata[
        split_metadata["source_split"]
        == "test"
    ]
    .copy()
)

train_validation_overlap = len(
    set(
        training_metadata[
            "campaign_group"
        ]
    )
    & set(
        validation_metadata[
            "campaign_group"
        ]
    )
)

if train_validation_overlap != 0:
    raise ValueError(
        "Training and validation campaigns overlap."
    )


# ------------------------------------------------
# 8. Match with existing OOF training manifest
# ------------------------------------------------

existing_oof_manifest = pd.read_csv(
    OOF_MANIFEST_PATH
)

existing_oof_rows = set(
    existing_oof_manifest[
        "source_row_index"
    ].astype(int)
)

locked_training_rows = set(
    training_metadata[
        "source_row_index"
    ].astype(int)
)

if existing_oof_rows != locked_training_rows:
    raise ValueError(
        "OOF training rows do not match "
        "the locked training split."
    )


# ------------------------------------------------
# 9. Read completed OOF results
# ------------------------------------------------

oof_comparison = pd.read_csv(
    OOF_COMPARISON_PATH
)

fusion_metrics = pd.read_csv(
    FUSION_METRICS_PATH
)

metadata_fold_metrics = pd.read_csv(
    METADATA_FOLD_METRICS_PATH
)

final_metadata_iterations = int(
    round(
        metadata_fold_metrics[
            "Selected_Iterations"
        ].median()
    )
)

optimized_fusion_row = (
    fusion_metrics[
        fusion_metrics["Threshold_Type"]
        == "OOF F1 Optimized"
    ]
    .iloc[0]
)

oof_fusion_threshold = float(
    optimized_fusion_row["Threshold"]
)


# ------------------------------------------------
# 10. Create immutable artifact inventory
# ------------------------------------------------

inventory_rows = []

for artifact_path in required_artifacts:
    inventory_rows.append({
        "Artifact": artifact_path.name,
        "Path": str(artifact_path),
        "SHA256": file_sha256(
            artifact_path
        )
    })

artifact_inventory = pd.DataFrame(
    inventory_rows
)

inventory_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_prevalidation_artifact_inventory.csv"
)

artifact_inventory.to_csv(
    inventory_path,
    index=False
)


# ------------------------------------------------
# 11. FREEZE architecture before reading
# validation target labels
# ------------------------------------------------

freeze_information = {
    "architecture_frozen": True,
    "frozen_utc":
        datetime.now(timezone.utc).isoformat(),
    "experiment_name":
        "SAGE-FJD",
    "full_name":
        (
            "Section-Aware Group-Isolated "
            "Evidence Fusion for Fraudulent "
            "Job Detection"
        ),
    "dataset":
        "EMSCAD fake_job_postings.csv",
    "protocol":
        "Leakage-Safe",
    "training_rows":
        12525,
    "validation_rows":
        2675,
    "test_rows":
        2680,
    "campaign_overlap":
        0,
    "views": {
        "lexical": {
            "representation":
                "Word and character TF-IDF",
            "word_features":
                80000,
            "character_features":
                150000,
            "classifier":
                "LinearSVC",
            "C":
                1.0
        },
        "structural_metadata": {
            "features":
                56,
            "classifier":
                "CatBoost",
            "final_iterations":
                final_metadata_iterations,
            "depth":
                7,
            "learning_rate":
                0.04
        },
        "semantic": {
            "embedding_model":
                (
                    "sentence-transformers/"
                    "all-MiniLM-L6-v2"
                ),
            "sections": [
                "title",
                "company_profile",
                "description",
                "requirements",
                "benefits"
            ],
            "window_tokens":
                220,
            "window_stride":
                180,
            "pooling":
                [
                    "mean",
                    "maximum",
                    "cross-section cosine"
                ],
            "classifier":
                "LogisticRegression",
            "C":
                0.35
        },
        "campaign": {
            "features":
                46,
            "feature_generation":
                (
                    "Nested group-safe template "
                    "novelty and fraud risk"
                ),
            "classifier":
                "CatBoost",
            "iterations":
                500,
            "depth":
                5
        }
    },
    "fusion": {
        "calibration":
            "Fold-local Platt calibration",
        "reliability":
            (
                "Squared PR-AUC skill "
                "above prevalence"
            ),
        "meta_model":
            "CatBoost",
        "iterations":
            400,
        "depth":
            4,
        "meta_model_weight":
            0.70,
        "reliability_score_weight":
            0.30
    },
    "oof_results": {
        "fusion_pr_auc":
            float(
                optimized_fusion_row[
                    "PR_AUC"
                ]
            ),
        "fusion_f1":
            float(
                optimized_fusion_row[
                    "F1"
                ]
            ),
        "fusion_mcc":
            float(
                optimized_fusion_row[
                    "MCC"
                ]
            ),
        "oof_diagnostic_threshold":
            oof_fusion_threshold
    },
    "validation_threshold_policy": {
        "primary_rule":
            (
                "Maximum validation F1 while "
                "precision is at least 0.90"
            ),
        "fallback_rule":
            (
                "Maximum validation F1 if no "
                "threshold reaches precision 0.90"
            ),
        "threshold_then_locked_for_test":
            True
    },
    "primary_metrics": [
        "F1",
        "PR_AUC",
        "MCC"
    ],
    "guardrails": {
        "minimum_precision":
            0.90,
        "target_recall":
            0.80
    },
    "validation_evaluated_at_freeze":
        False,
    "test_evaluated":
        False,
    "artifact_inventory":
        str(inventory_path),
    "artifact_inventory_sha256":
        file_sha256(inventory_path)
}

if FREEZE_PATH.is_file():

    with open(
        FREEZE_PATH,
        "r",
        encoding="utf-8"
    ) as freeze_file:
        existing_freeze = json.load(
            freeze_file
        )

    if not existing_freeze.get(
        "architecture_frozen",
        False
    ):
        raise ValueError(
            "Existing freeze file is invalid."
        )

    print(
        "Existing architecture freeze preserved."
    )

else:

    with open(
        FREEZE_PATH,
        "w",
        encoding="utf-8"
    ) as freeze_file:
        json.dump(
            freeze_information,
            freeze_file,
            indent=2
        )

freeze_sha256 = file_sha256(
    FREEZE_PATH
)


# ------------------------------------------------
# 12. Only now retain train/validation labels
# Test labels are never retained or evaluated
# ------------------------------------------------

retained_label_chunks = []
manifest_cursor = 0

for target_chunk in pd.read_csv(
    LOCKED_MANIFEST_PATH,
    usecols=[target_column],
    chunksize=2000
):
    chunk_positions = np.arange(
        manifest_cursor,
        manifest_cursor
        + len(target_chunk)
    )

    chunk_splits = (
        split_metadata.iloc[
            chunk_positions
        ]["source_split"].to_numpy()
    )

    keep_mask = (
        chunk_splits != "test"
    )

    if keep_mask.any():
        retained = pd.DataFrame({
            "manifest_position":
                chunk_positions[keep_mask],
            "fraudulent":
                pd.to_numeric(
                    target_chunk.loc[
                        keep_mask,
                        target_column
                    ],
                    errors="coerce"
                ).to_numpy()
        })

        retained_label_chunks.append(
            retained
        )

    manifest_cursor += len(target_chunk)

retained_labels = pd.concat(
    retained_label_chunks,
    ignore_index=True
)

if retained_labels["fraudulent"].isna().any():
    raise ValueError(
        "Invalid train/validation labels."
    )

retained_labels["fraudulent"] = (
    retained_labels["fraudulent"]
    .astype(int)
)

split_metadata[
    "manifest_position"
] = np.arange(
    len(split_metadata)
)

train_validation_data = (
    split_metadata[
        split_metadata["source_split"]
        .isin(["train", "validation"])
    ]
    .merge(
        retained_labels,
        on="manifest_position",
        how="left",
        validate="one_to_one"
    )
)

final_training_manifest = (
    train_validation_data[
        train_validation_data[
            "source_split"
        ] == "train"
    ]
    .copy()
)

locked_validation_data = (
    train_validation_data[
        train_validation_data[
            "source_split"
        ] == "validation"
    ]
    .copy()
)

if len(final_training_manifest) != 12525:
    raise ValueError(
        "Final training row count mismatch."
    )

if int(
    final_training_manifest[
        "fraudulent"
    ].sum()
) != 609:
    raise ValueError(
        "Final training fraud count mismatch."
    )

if len(locked_validation_data) != 2675:
    raise ValueError(
        "Validation row count mismatch."
    )

if int(
    locked_validation_data[
        "fraudulent"
    ].sum()
) != 129:
    raise ValueError(
        "Validation fraud count mismatch."
    )


# ------------------------------------------------
# 13. Save separated manifests
# ------------------------------------------------

manifest_output_columns = [
    "source_row_index",
    "campaign_group",
    "source_split"
]

if job_id_column is not None:
    manifest_output_columns.insert(
        1,
        job_id_column
    )

training_output_columns = (
    manifest_output_columns
    + ["fraudulent"]
)

final_training_manifest[
    training_output_columns
].to_csv(
    FINAL_TRAIN_MANIFEST_PATH,
    index=False
)

# Validation feature manifest contains no target
locked_validation_data[
    manifest_output_columns
].to_csv(
    VALIDATION_FEATURE_MANIFEST_PATH,
    index=False
)

# Stored separately and not used until evaluation
locked_validation_data[
    [
        "source_row_index",
        "fraudulent"
    ]
].to_csv(
    SEALED_VALIDATION_LABELS_PATH,
    index=False
)


# ------------------------------------------------
# 14. Save post-freeze preparation audit
# ------------------------------------------------

validation_audit = {
    "prepared_utc":
        datetime.now(timezone.utc).isoformat(),
    "architecture_freeze":
        str(FREEZE_PATH),
    "architecture_freeze_sha256":
        freeze_sha256,
    "training_rows":
        len(final_training_manifest),
    "training_fraudulent":
        int(
            final_training_manifest[
                "fraudulent"
            ].sum()
        ),
    "validation_rows":
        len(locked_validation_data),
    "validation_fraudulent":
        int(
            locked_validation_data[
                "fraudulent"
            ].sum()
        ),
    "test_rows":
        len(test_metadata),
    "train_validation_campaign_overlap":
        train_validation_overlap,
    "validation_labels_sealed":
        True,
    "validation_evaluated":
        False,
    "test_labels_retained":
        False,
    "test_evaluated":
        False,
    "training_manifest_sha256":
        file_sha256(
            FINAL_TRAIN_MANIFEST_PATH
        ),
    "validation_manifest_sha256":
        file_sha256(
            VALIDATION_FEATURE_MANIFEST_PATH
        ),
    "sealed_validation_labels_sha256":
        file_sha256(
            SEALED_VALIDATION_LABELS_PATH
        )
}

with open(
    VALIDATION_AUDIT_PATH,
    "w",
    encoding="utf-8"
) as audit_file:
    json.dump(
        validation_audit,
        audit_file,
        indent=2
    )


# ------------------------------------------------
# 15. Create recovery checkpoint
# ------------------------------------------------

checkpoint_zip = Path(
    shutil.make_archive(
        "/kaggle/working/"
        "sage_fjd_step_08_frozen_checkpoint",
        "zip",
        root_dir=PROJECT_DIRECTORY
    )
)


# ------------------------------------------------
# 16. Display freeze results
# ------------------------------------------------

split_audit_table = pd.DataFrame([
    {
        "Split": "Train",
        "Rows": len(
            final_training_manifest
        ),
        "Fraudulent": int(
            final_training_manifest[
                "fraudulent"
            ].sum()
        ),
        "Campaign_Groups": int(
            final_training_manifest[
                "campaign_group"
            ].nunique()
        )
    },
    {
        "Split": "Validation",
        "Rows": len(
            locked_validation_data
        ),
        "Fraudulent": int(
            locked_validation_data[
                "fraudulent"
            ].sum()
        ),
        "Campaign_Groups": int(
            locked_validation_data[
                "campaign_group"
            ].nunique()
        )
    },
    {
        "Split": "Test",
        "Rows": len(test_metadata),
        "Fraudulent": "SEALED",
        "Campaign_Groups": int(
            test_metadata[
                "campaign_group"
            ].nunique()
        )
    }
])

frozen_architecture_table = pd.DataFrame([
    {
        "Component": "Lexical",
        "Frozen_Design":
            "Word + character TF-IDF Linear SVM"
    },
    {
        "Component": "Metadata",
        "Frozen_Design":
            (
                "56 features + CatBoost, "
                f"{final_metadata_iterations} iterations"
            )
    },
    {
        "Component": "Semantic",
        "Frozen_Design":
            (
                "5-section multi-window MiniLM "
                "+ Logistic Regression"
            )
    },
    {
        "Component": "Campaign",
        "Frozen_Design":
            (
                "46 nested group-safe risk features "
                "+ CatBoost"
            )
    },
    {
        "Component": "Fusion",
        "Frozen_Design":
            (
                "Platt calibration + reliability "
                "+ CatBoost 70/30 blend"
            )
    }
])

print("\nCURRENT OOF COMPARISON")
display(
    oof_comparison.round(4)
)

print("\nFROZEN ARCHITECTURE")
display(
    frozen_architecture_table
)

print("\nLOCKED SPLIT AUDIT")
display(
    split_audit_table
)

print("\n" + "=" * 72)
print("SAGE-FJD STEP 8 COMPLETED — ARCHITECTURE FROZEN")
print("=" * 72)
print("Freeze file:", FREEZE_PATH)
print("Freeze SHA256:", freeze_sha256)
print(
    "Final metadata iterations:",
    final_metadata_iterations
)
print(
    "OOF diagnostic threshold:",
    round(oof_fusion_threshold, 4)
)
print("Validation labels: SEALED")
print("Validation evaluated: False")
print("Test labels retained: False")
print("Test evaluated: False")
print("Checkpoint ZIP:", checkpoint_zip)
print(
    "Next step: train the final lexical branch "
    "and predict locked validation."
)
print("=" * 72)