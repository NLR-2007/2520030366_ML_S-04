# ================================================================
# SAGE-FJD — STEP 3
# LEXICAL VIEW: WORD + CHARACTER TF-IDF + LINEAR SVM
# FIVE GROUP-ISOLATED OOF MODELS
# ================================================================

from pathlib import Path
from datetime import datetime, timezone
import gc
import hashlib
import html
import json
import shutil
import time
import warnings

import numpy as np
import pandas as pd

from scipy.sparse import hstack

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score
)

from IPython.display import display


# ------------------------------------------------
# 1. Configuration
# ------------------------------------------------

SEED = 42

PROJECT_DIRECTORY = Path(
    "/kaggle/working/proposed_sage_fjd"
)

OOF_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_manifest.csv"
)

TEXT_FIELDS = [
    "title",
    "company_profile",
    "description",
    "requirements",
    "benefits"
]

WORD_MAX_FEATURES = 80000
CHARACTER_MAX_FEATURES = 150000

WORD_NGRAM_RANGE = (1, 2)
CHARACTER_NGRAM_RANGE = (3, 5)

SVM_C = 1.0

if not OOF_MANIFEST_PATH.is_file():
    raise FileNotFoundError(
        "Step 2 OOF manifest was not found: "
        f"{OOF_MANIFEST_PATH}"
    )


# ------------------------------------------------
# 2. Locate EMSCAD dataset
# ------------------------------------------------

dataset_candidates = []

for variable_name in [
    "dataset_path",
    "DATASET_PATH"
]:
    if variable_name in globals():
        possible_path = Path(
            str(globals()[variable_name])
        )

        if possible_path.is_file():
            dataset_candidates.append(possible_path)

dataset_candidates.extend([
    Path(
        "/kaggle/input/datasets/shivamb/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    ),
    Path(
        "/kaggle/input/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    )
])

if Path("/kaggle/input").exists():
    dataset_candidates.extend(
        Path("/kaggle/input").rglob(
            "fake_job_postings.csv"
        )
    )

dataset_candidates = [
    path
    for path in dataset_candidates
    if path.is_file()
]

if not dataset_candidates:
    raise FileNotFoundError(
        "fake_job_postings.csv was not found."
    )

DATASET_PATH = dataset_candidates[0]

print("=" * 72)
print("SAGE-FJD STEP 3 — LEXICAL OOF BRANCH")
print("=" * 72)
print("Dataset:", DATASET_PATH)
print("OOF manifest:", OOF_MANIFEST_PATH)
print("This stage uses CPU.")
print("Validation and test rows will not be used.")


# ------------------------------------------------
# 3. Load and validate OOF manifest
# ------------------------------------------------

oof_manifest = pd.read_csv(
    OOF_MANIFEST_PATH
)

required_manifest_columns = [
    "source_row_index",
    "fraudulent",
    "campaign_group",
    "oof_fold",
    "source_split"
]

missing_manifest_columns = [
    column
    for column in required_manifest_columns
    if column not in oof_manifest.columns
]

if missing_manifest_columns:
    raise ValueError(
        "Missing OOF manifest columns: "
        + ", ".join(missing_manifest_columns)
    )

if not (
    oof_manifest["source_split"]
    .astype(str)
    .str.lower()
    .eq("train")
    .all()
):
    raise ValueError(
        "OOF manifest contains non-training rows."
    )

if len(oof_manifest) != 12525:
    raise ValueError(
        "Expected 12,525 training rows, found "
        f"{len(oof_manifest)}."
    )

if int(oof_manifest["fraudulent"].sum()) != 609:
    raise ValueError(
        "Expected 609 fraudulent training rows."
    )

if oof_manifest["source_row_index"].duplicated().any():
    raise ValueError(
        "Duplicate source rows exist."
    )

campaign_fold_count = (
    oof_manifest
    .groupby("campaign_group")["oof_fold"]
    .nunique()
)

if int((campaign_fold_count > 1).sum()) != 0:
    raise ValueError(
        "Campaign groups cross OOF folds."
    )

observed_folds = sorted(
    oof_manifest["oof_fold"]
    .astype(int)
    .unique()
    .tolist()
)

if observed_folds != [1, 2, 3, 4, 5]:
    raise ValueError(
        f"Unexpected OOF folds: {observed_folds}"
    )


# ------------------------------------------------
# 4. Validate dataset text columns
# ------------------------------------------------

dataset_columns = pd.read_csv(
    DATASET_PATH,
    nrows=0
).columns.tolist()

missing_text_fields = [
    field
    for field in TEXT_FIELDS
    if field not in dataset_columns
]

if missing_text_fields:
    raise ValueError(
        "Dataset text fields are missing: "
        + ", ".join(missing_text_fields)
    )


# ------------------------------------------------
# 5. Retain only leakage-safe training text
# ------------------------------------------------

wanted_source_rows = set(
    oof_manifest["source_row_index"]
    .astype(int)
    .tolist()
)

selected_training_chunks = []
row_cursor = 0

print("\nLoading only the required training text...")

for dataset_chunk in pd.read_csv(
    DATASET_PATH,
    usecols=TEXT_FIELDS,
    chunksize=2000
):
    chunk_source_rows = np.arange(
        row_cursor,
        row_cursor + len(dataset_chunk)
    )

    keep_mask = np.isin(
        chunk_source_rows,
        list(wanted_source_rows)
    )

    if keep_mask.any():
        retained_chunk = (
            dataset_chunk.loc[keep_mask]
            .copy()
            .reset_index(drop=True)
        )

        retained_chunk.insert(
            0,
            "source_row_index",
            chunk_source_rows[keep_mask]
        )

        selected_training_chunks.append(
            retained_chunk
        )

    row_cursor += len(dataset_chunk)

training_text = pd.concat(
    selected_training_chunks,
    ignore_index=True
)

del selected_training_chunks
gc.collect()

if len(training_text) != len(oof_manifest):
    raise ValueError(
        "Training-text row count mismatch. "
        f"Expected {len(oof_manifest)}, "
        f"found {len(training_text)}."
    )

training_data = oof_manifest.merge(
    training_text,
    on="source_row_index",
    how="left",
    validate="one_to_one"
)

if training_data[TEXT_FIELDS].isna().all(axis=1).any():
    raise ValueError(
        "Some training rows have no available text."
    )

training_data = (
    training_data
    .sort_values("source_row_index")
    .reset_index(drop=True)
)


# ------------------------------------------------
# 6. Clean text without destroying fraud signals
# ------------------------------------------------

def clean_text_series(series):
    cleaned = (
        series
        .fillna("")
        .astype(str)
        .map(html.unescape)
    )

    cleaned = cleaned.str.replace(
        r"<[^>]+>",
        " ",
        regex=True
    )

    cleaned = cleaned.str.replace(
        r"[\r\n\t]+",
        " ",
        regex=True
    )

    cleaned = cleaned.str.replace(
        r"\s+",
        " ",
        regex=True
    ).str.strip()

    return cleaned


combined_text = pd.Series(
    "",
    index=training_data.index,
    dtype="object"
)

for text_field in TEXT_FIELDS:
    cleaned_field = clean_text_series(
        training_data[text_field]
    )

    combined_text = (
        combined_text
        + " __"
        + text_field
        + "__ "
        + cleaned_field
    )

training_data["lexical_text"] = (
    combined_text.str.strip()
)

empty_text_count = int(
    training_data["lexical_text"]
    .str.replace(
        r"__[a-z_]+__",
        "",
        regex=True
    )
    .str.strip()
    .eq("")
    .sum()
)

print("Training rows retained:", len(training_data))
print("Fraudulent rows:", int(training_data["fraudulent"].sum()))
print("Empty text rows:", empty_text_count)
print("Validation/test rows used: 0")


# ------------------------------------------------
# 7. Metric helpers
# ------------------------------------------------

def evaluate_scores(
    labels,
    scores,
    threshold
):
    predictions = (
        np.asarray(scores) >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        labels,
        predictions,
        labels=[0, 1]
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "Threshold": float(threshold),
        "Accuracy": accuracy_score(
            labels,
            predictions
        ),
        "Precision": precision_score(
            labels,
            predictions,
            zero_division=0
        ),
        "Recall": recall_score(
            labels,
            predictions,
            zero_division=0
        ),
        "F1": f1_score(
            labels,
            predictions,
            zero_division=0
        ),
        "Specificity": specificity,
        "Balanced_Accuracy":
            balanced_accuracy_score(
                labels,
                predictions
            ),
        "PR_AUC": average_precision_score(
            labels,
            scores
        ),
        "ROC_AUC": roc_auc_score(
            labels,
            scores
        ),
        "MCC": matthews_corrcoef(
            labels,
            predictions
        ),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp)
    }


def find_best_f1_threshold(
    labels,
    scores,
    minimum_precision=None
):
    precision_values, recall_values, thresholds = (
        precision_recall_curve(
            labels,
            scores
        )
    )

    precision_values = precision_values[:-1]
    recall_values = recall_values[:-1]

    f1_values = (
        2
        * precision_values
        * recall_values
        / (
            precision_values
            + recall_values
            + 1e-12
        )
    )

    valid_mask = np.isfinite(f1_values)

    if minimum_precision is not None:
        valid_mask &= (
            precision_values
            >= minimum_precision
        )

    if not valid_mask.any():
        raise ValueError(
            "No threshold satisfies the "
            "precision requirement."
        )

    candidate_scores = np.where(
        valid_mask,
        f1_values,
        -1.0
    )

    best_position = int(
        np.argmax(candidate_scores)
    )

    return float(thresholds[best_position])


# ------------------------------------------------
# 8. Generate lexical OOF predictions
# ------------------------------------------------

labels = (
    training_data["fraudulent"]
    .astype(int)
    .to_numpy()
)

fold_assignments = (
    training_data["oof_fold"]
    .astype(int)
    .to_numpy()
)

campaign_groups = (
    training_data["campaign_group"]
    .astype(str)
    .to_numpy()
)

lexical_documents = (
    training_data["lexical_text"]
    .astype(str)
    .to_numpy()
)

oof_margin = np.full(
    len(training_data),
    np.nan,
    dtype=np.float64
)

fold_metric_rows = []

total_start_time = time.perf_counter()

for fold_number in observed_folds:

    print("\n" + "=" * 72)
    print(
        f"LEXICAL OOF TRAINING — FOLD "
        f"{fold_number}/5"
    )
    print("=" * 72)

    fold_start_time = time.perf_counter()

    holdout_mask = (
        fold_assignments == fold_number
    )

    training_mask = ~holdout_mask

    fold_training_groups = set(
        campaign_groups[training_mask]
    )

    fold_holdout_groups = set(
        campaign_groups[holdout_mask]
    )

    group_overlap = (
        fold_training_groups
        & fold_holdout_groups
    )

    if group_overlap:
        raise ValueError(
            f"Fold {fold_number} contains "
            "campaign leakage."
        )

    training_documents = (
        lexical_documents[training_mask]
    )

    holdout_documents = (
        lexical_documents[holdout_mask]
    )

    training_labels = labels[training_mask]
    holdout_labels = labels[holdout_mask]

    # Word-level evidence
    word_vectorizer = TfidfVectorizer(
        analyzer="word",
        ngram_range=WORD_NGRAM_RANGE,
        min_df=2,
        max_df=0.995,
        max_features=WORD_MAX_FEATURES,
        sublinear_tf=True,
        strip_accents="unicode",
        lowercase=True,
        dtype=np.float32,
        token_pattern=r"(?u)\b\w\w+\b"
    )

    fold_word_training = (
        word_vectorizer.fit_transform(
            training_documents
        )
    )

    fold_word_holdout = (
        word_vectorizer.transform(
            holdout_documents
        )
    )

    # Character-level evidence
    character_vectorizer = TfidfVectorizer(
        analyzer="char_wb",
        ngram_range=CHARACTER_NGRAM_RANGE,
        min_df=2,
        max_df=0.995,
        max_features=CHARACTER_MAX_FEATURES,
        sublinear_tf=True,
        lowercase=True,
        dtype=np.float32
    )

    fold_character_training = (
        character_vectorizer.fit_transform(
            training_documents
        )
    )

    fold_character_holdout = (
        character_vectorizer.transform(
            holdout_documents
        )
    )

    fold_training_features = hstack(
        [
            fold_word_training,
            fold_character_training
        ],
        format="csr",
        dtype=np.float32
    )

    fold_holdout_features = hstack(
        [
            fold_word_holdout,
            fold_character_holdout
        ],
        format="csr",
        dtype=np.float32
    )

    lexical_model = LinearSVC(
        C=SVM_C,
        class_weight="balanced",
        random_state=SEED,
        max_iter=10000,
        dual="auto"
    )

    with warnings.catch_warnings():
        warnings.simplefilter("always")
        lexical_model.fit(
            fold_training_features,
            training_labels
        )

    holdout_margin = (
        lexical_model.decision_function(
            fold_holdout_features
        )
    )

    oof_margin[holdout_mask] = holdout_margin

    fold_metrics = evaluate_scores(
        holdout_labels,
        holdout_margin,
        threshold=0.0
    )

    fold_time_seconds = (
        time.perf_counter()
        - fold_start_time
    )

    fold_metric_rows.append({
        "OOF_Fold": fold_number,
        "Training_Rows": int(training_mask.sum()),
        "Holdout_Rows": int(holdout_mask.sum()),
        "Holdout_Fraudulent": int(
            holdout_labels.sum()
        ),
        "Word_Features": int(
            fold_word_training.shape[1]
        ),
        "Character_Features": int(
            fold_character_training.shape[1]
        ),
        "PR_AUC": fold_metrics["PR_AUC"],
        "ROC_AUC": fold_metrics["ROC_AUC"],
        "Precision_at_0": fold_metrics["Precision"],
        "Recall_at_0": fold_metrics["Recall"],
        "F1_at_0": fold_metrics["F1"],
        "MCC_at_0": fold_metrics["MCC"],
        "Training_Time_Seconds":
            fold_time_seconds,
        "Crossing_Campaign_Groups":
            len(group_overlap)
    })

    print(
        "Word features:",
        fold_word_training.shape[1]
    )
    print(
        "Character features:",
        fold_character_training.shape[1]
    )
    print(
        "PR-AUC:",
        round(fold_metrics["PR_AUC"], 4)
    )
    print(
        "F1 at threshold 0:",
        round(fold_metrics["F1"], 4)
    )
    print(
        "Fold time:",
        round(fold_time_seconds, 2),
        "seconds"
    )

    del (
        word_vectorizer,
        character_vectorizer,
        lexical_model,
        fold_word_training,
        fold_word_holdout,
        fold_character_training,
        fold_character_holdout,
        fold_training_features,
        fold_holdout_features
    )

    gc.collect()

if np.isnan(oof_margin).any():
    raise ValueError(
        "Some rows did not receive lexical "
        "OOF predictions."
    )

total_training_seconds = (
    time.perf_counter()
    - total_start_time
)


# ------------------------------------------------
# 9. Pooled OOF threshold diagnostics
# ------------------------------------------------

best_f1_threshold = find_best_f1_threshold(
    labels,
    oof_margin
)

precision_guardrail_threshold = (
    find_best_f1_threshold(
        labels,
        oof_margin,
        minimum_precision=0.90
    )
)

pooled_metric_rows = []

for threshold_type, threshold in [
    ("Default 0.00", 0.0),
    (
        "OOF F1 Optimized",
        best_f1_threshold
    ),
    (
        "Precision >= 0.90",
        precision_guardrail_threshold
    )
]:
    metric_row = evaluate_scores(
        labels,
        oof_margin,
        threshold
    )

    metric_row["Threshold_Type"] = (
        threshold_type
    )

    pooled_metric_rows.append(metric_row)

pooled_metrics = pd.DataFrame(
    pooled_metric_rows
)

pooled_metrics = pooled_metrics[
    [
        "Threshold_Type",
        "Threshold",
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "Specificity",
        "Balanced_Accuracy",
        "PR_AUC",
        "ROC_AUC",
        "MCC",
        "TN",
        "FP",
        "FN",
        "TP"
    ]
]

fold_metrics_table = pd.DataFrame(
    fold_metric_rows
)


# ------------------------------------------------
# 10. Save lexical OOF artifacts
# ------------------------------------------------

lexical_probability_proxy = (
    1.0
    / (
        1.0
        + np.exp(
            -np.clip(
                oof_margin,
                -30,
                30
            )
        )
    )
)

lexical_predictions = oof_manifest.copy()

score_lookup = pd.DataFrame({
    "source_row_index":
        training_data["source_row_index"],
    "lexical_margin":
        oof_margin,
    "lexical_sigmoid_score":
        lexical_probability_proxy
})

lexical_predictions = (
    lexical_predictions
    .merge(
        score_lookup,
        on="source_row_index",
        how="left",
        validate="one_to_one"
    )
    .sort_values("source_row_index")
    .reset_index(drop=True)
)

prediction_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_lexical_oof_predictions.csv"
)

fold_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_lexical_oof_fold_metrics.csv"
)

pooled_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_lexical_oof_pooled_metrics.csv"
)

configuration_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_lexical_configuration.json"
)

lexical_predictions.to_csv(
    prediction_path,
    index=False
)

fold_metrics_table.to_csv(
    fold_metrics_path,
    index=False
)

pooled_metrics.to_csv(
    pooled_metrics_path,
    index=False
)


def calculate_sha256(file_path):
    checksum = hashlib.sha256()

    with open(file_path, "rb") as file_handle:
        for block in iter(
            lambda: file_handle.read(
                1024 * 1024
            ),
            b""
        ):
            checksum.update(block)

    return checksum.hexdigest()


configuration = {
    "created_utc":
        datetime.now(timezone.utc).isoformat(),

    "experiment":
        "SAGE-FJD",

    "step":
        3,

    "view":
        "Lexical",

    "dataset":
        str(DATASET_PATH),

    "oof_manifest":
        str(OOF_MANIFEST_PATH),

    "text_fields":
        TEXT_FIELDS,

    "word_max_features":
        WORD_MAX_FEATURES,

    "word_ngram_range":
        list(WORD_NGRAM_RANGE),

    "character_max_features":
        CHARACTER_MAX_FEATURES,

    "character_ngram_range":
        list(CHARACTER_NGRAM_RANGE),

    "classifier":
        "LinearSVC",

    "svm_c":
        SVM_C,

    "class_weight":
        "balanced",

    "number_of_oof_folds":
        5,

    "random_seed":
        SEED,

    "training_rows":
        len(training_data),

    "fraudulent_rows":
        int(labels.sum()),

    "total_training_seconds":
        total_training_seconds,

    "pooled_oof_pr_auc":
        float(
            average_precision_score(
                labels,
                oof_margin
            )
        ),

    "best_oof_f1_threshold":
        best_f1_threshold,

    "precision_guardrail_threshold":
        precision_guardrail_threshold,

    "campaign_overlap":
        0,

    "validation_rows_used":
        0,

    "test_rows_used":
        0,

    "test_evaluated":
        False,

    "prediction_file_sha256":
        calculate_sha256(prediction_path)
}

with open(
    configuration_path,
    "w",
    encoding="utf-8"
) as configuration_file:
    json.dump(
        configuration,
        configuration_file,
        indent=2
    )


# ------------------------------------------------
# 11. Create Step 3 recovery checkpoint
# ------------------------------------------------

checkpoint_base = Path(
    "/kaggle/working/"
    "sage_fjd_step_03_checkpoint"
)

checkpoint_zip = Path(
    shutil.make_archive(
        str(checkpoint_base),
        "zip",
        root_dir=PROJECT_DIRECTORY
    )
)


# ------------------------------------------------
# 12. Display final Step 3 results
# ------------------------------------------------

print("\nLEXICAL OOF FOLD RESULTS")
display(
    fold_metrics_table.round(4)
)

print("\nPOOLED LEXICAL OOF RESULTS")
display(
    pooled_metrics.round(4)
)

print("\n" + "=" * 72)
print("SAGE-FJD PROPOSED MODEL STEP 3 COMPLETED")
print("=" * 72)
print(
    "Total training time:",
    round(total_training_seconds / 60, 2),
    "minutes"
)
print(
    "Pooled OOF PR-AUC:",
    round(
        average_precision_score(
            labels,
            oof_margin
        ),
        4
    )
)
print(
    "Best OOF F1 threshold:",
    round(best_f1_threshold, 4)
)
print("Campaign overlap: 0")
print("Validation rows used: 0")
print("Test rows used: 0")
print("Test evaluated: False")
print("Predictions:", prediction_path)
print("Checkpoint ZIP:", checkpoint_zip)
print("Next step: structural/metadata OOF branch.")
print("=" * 72)