# ================================================================
# SAGE-FJD — STEP 7
# CROSS-FITTED RELIABILITY-AWARE MULTI-VIEW FUSION
# ================================================================

from pathlib import Path
from datetime import datetime, timezone
import gc
import hashlib
import json
import shutil
import time

import numpy as np
import pandas as pd

from catboost import CatBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score
)

from IPython.display import display


# ------------------------------------------------
# 1. Configuration
# ------------------------------------------------

SEED = 42

# Fixed before seeing fusion results
META_MODEL_WEIGHT = 0.70
RELIABILITY_SCORE_WEIGHT = 0.30

PROJECT_DIRECTORY = Path(
    "/kaggle/working/proposed_sage_fjd"
)

OOF_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_manifest.csv"
)

BRANCH_FILES = {
    "Lexical": (
        PROJECT_DIRECTORY
        / "sage_fjd_lexical_oof_predictions.csv"
    ),
    "Metadata": (
        PROJECT_DIRECTORY
        / "sage_fjd_metadata_oof_predictions.csv"
    ),
    "Semantic": (
        PROJECT_DIRECTORY
        / "sage_fjd_semantic_oof_predictions.csv"
    ),
    "Campaign": (
        PROJECT_DIRECTORY
        / "sage_fjd_campaign_oof_predictions.csv"
    )
}

BRANCH_SCORE_COLUMNS = {
    "Lexical": "lexical_margin",
    "Metadata": "metadata_probability",
    "Semantic": "semantic_probability",
    "Campaign": "campaign_probability"
}

BRANCH_NAMES = list(
    BRANCH_FILES.keys()
)

for branch_name, branch_path in BRANCH_FILES.items():
    if not branch_path.is_file():
        raise FileNotFoundError(
            f"{branch_name} prediction file "
            f"was not found: {branch_path}"
        )


# ------------------------------------------------
# 2. Load and align all four views
# ------------------------------------------------

oof_manifest = pd.read_csv(
    OOF_MANIFEST_PATH
)

required_manifest_columns = [
    "source_row_index",
    "fraudulent",
    "campaign_group",
    "oof_fold",
    "source_split"
]

missing_manifest_columns = [
    column
    for column in required_manifest_columns
    if column not in oof_manifest.columns
]

if missing_manifest_columns:
    raise ValueError(
        "Missing manifest columns: "
        + ", ".join(missing_manifest_columns)
    )

fusion_data = oof_manifest.copy()

for branch_name in BRANCH_NAMES:

    branch_frame = pd.read_csv(
        BRANCH_FILES[branch_name]
    )

    score_column = BRANCH_SCORE_COLUMNS[
        branch_name
    ]

    if score_column not in branch_frame.columns:
        raise ValueError(
            f"{score_column} is missing from "
            f"{branch_name} predictions."
        )

    branch_subset = branch_frame[
        [
            "source_row_index",
            score_column
        ]
    ].copy()

    fusion_data = fusion_data.merge(
        branch_subset,
        on="source_row_index",
        how="left",
        validate="one_to_one"
    )

fusion_data = (
    fusion_data
    .sort_values("source_row_index")
    .reset_index(drop=True)
)

if len(fusion_data) != 12525:
    raise ValueError(
        "Expected 12,525 fusion rows."
    )

if int(fusion_data["fraudulent"].sum()) != 609:
    raise ValueError(
        "Expected 609 fraudulent rows."
    )

if fusion_data[
    list(BRANCH_SCORE_COLUMNS.values())
].isna().any().any():
    raise ValueError(
        "Missing branch predictions were found."
    )

campaign_overlap = int(
    (
        fusion_data
        .groupby("campaign_group")["oof_fold"]
        .nunique()
        > 1
    ).sum()
)

if campaign_overlap != 0:
    raise ValueError(
        "Campaign groups cross OOF folds."
    )

print("=" * 72)
print("SAGE-FJD STEP 7 — RELIABILITY-AWARE FUSION")
print("=" * 72)
print("Rows:", len(fusion_data))
print(
    "Fraudulent:",
    int(fusion_data["fraudulent"].sum())
)
print("Views:", BRANCH_NAMES)
print("Campaign overlap:", campaign_overlap)
print("Validation/test rows used: 0")


# ------------------------------------------------
# 3. Fixed arrays
# ------------------------------------------------

labels = (
    fusion_data["fraudulent"]
    .astype(int)
    .to_numpy()
)

fold_assignments = (
    fusion_data["oof_fold"]
    .astype(int)
    .to_numpy()
)

campaign_groups = (
    fusion_data["campaign_group"]
    .astype(str)
    .to_numpy()
)

raw_branch_scores = {
    branch_name: (
        fusion_data[
            BRANCH_SCORE_COLUMNS[
                branch_name
            ]
        ]
        .astype(float)
        .to_numpy()
    )
    for branch_name in BRANCH_NAMES
}


# ------------------------------------------------
# 4. Metric helpers
# ------------------------------------------------

def evaluate_scores(
    true_labels,
    scores,
    threshold
):
    predictions = (
        scores >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        true_labels,
        predictions,
        labels=[0, 1]
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "Threshold": float(threshold),
        "Accuracy": accuracy_score(
            true_labels,
            predictions
        ),
        "Precision": precision_score(
            true_labels,
            predictions,
            zero_division=0
        ),
        "Recall": recall_score(
            true_labels,
            predictions,
            zero_division=0
        ),
        "F1": f1_score(
            true_labels,
            predictions,
            zero_division=0
        ),
        "Specificity": specificity,
        "Balanced_Accuracy":
            balanced_accuracy_score(
                true_labels,
                predictions
            ),
        "PR_AUC": average_precision_score(
            true_labels,
            scores
        ),
        "ROC_AUC": roc_auc_score(
            true_labels,
            scores
        ),
        "MCC": matthews_corrcoef(
            true_labels,
            predictions
        ),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp)
    }


def find_best_threshold(
    true_labels,
    scores,
    minimum_precision=None
):
    precision_values, recall_values, thresholds = (
        precision_recall_curve(
            true_labels,
            scores
        )
    )

    precision_values = precision_values[:-1]
    recall_values = recall_values[:-1]

    f1_values = (
        2
        * precision_values
        * recall_values
        / (
            precision_values
            + recall_values
            + 1e-12
        )
    )

    valid_mask = np.isfinite(f1_values)

    if minimum_precision is not None:
        valid_mask &= (
            precision_values
            >= minimum_precision
        )

    if not valid_mask.any():
        raise ValueError(
            "No threshold satisfies the condition."
        )

    candidate_values = np.where(
        valid_mask,
        f1_values,
        -1.0
    )

    best_position = int(
        np.argmax(candidate_values)
    )

    return float(
        thresholds[best_position]
    )


def calibration_input(
    branch_name,
    scores
):
    scores = np.asarray(
        scores,
        dtype=np.float64
    )

    if branch_name == "Lexical":
        return scores.reshape(-1, 1)

    clipped_scores = np.clip(
        scores,
        1e-6,
        1 - 1e-6
    )

    logits = np.log(
        clipped_scores
        / (1 - clipped_scores)
    )

    return logits.reshape(-1, 1)


def fit_platt_calibrator(
    branch_name,
    training_scores,
    training_labels
):
    calibrator = LogisticRegression(
        C=1.0,
        penalty="l2",
        solver="lbfgs",
        max_iter=1000,
        random_state=SEED
    )

    calibrator.fit(
        calibration_input(
            branch_name,
            training_scores
        ),
        training_labels
    )

    return calibrator


def apply_calibrator(
    calibrator,
    branch_name,
    scores
):
    return calibrator.predict_proba(
        calibration_input(
            branch_name,
            scores
        )
    )[:, 1]


# ------------------------------------------------
# 5. Build dynamic fusion features
# ------------------------------------------------

def build_fusion_features(
    calibrated_scores,
    reliability_weights
):
    calibrated_scores = np.asarray(
        calibrated_scores,
        dtype=np.float64
    )

    reliability_weights = np.asarray(
        reliability_weights,
        dtype=np.float64
    )

    feature_values = {}

    clipped_scores = np.clip(
        calibrated_scores,
        1e-6,
        1 - 1e-6
    )

    calibrated_logits = np.log(
        clipped_scores
        / (1 - clipped_scores)
    )

    confidence_values = (
        np.abs(
            calibrated_scores - 0.5
        )
        * 2
    )

    for branch_index, branch_name in enumerate(
        BRANCH_NAMES
    ):
        normalized_name = (
            branch_name.lower()
        )

        feature_values[
            f"{normalized_name}_calibrated"
        ] = calibrated_scores[
            :,
            branch_index
        ]

        feature_values[
            f"{normalized_name}_logit"
        ] = calibrated_logits[
            :,
            branch_index
        ]

        feature_values[
            f"{normalized_name}_confidence"
        ] = confidence_values[
            :,
            branch_index
        ]

        feature_values[
            f"{normalized_name}_weighted_contribution"
        ] = (
            calibrated_scores[
                :,
                branch_index
            ]
            * reliability_weights[
                branch_index
            ]
        )

    score_mean = calibrated_scores.mean(
        axis=1
    )

    score_standard_deviation = (
        calibrated_scores.std(axis=1)
    )

    score_minimum = calibrated_scores.min(
        axis=1
    )

    score_maximum = calibrated_scores.max(
        axis=1
    )

    reliability_weighted_score = (
        calibrated_scores
        @ reliability_weights
    )

    reliability_weighted_confidence = (
        confidence_values
        @ reliability_weights
    )

    feature_values[
        "view_score_mean"
    ] = score_mean

    feature_values[
        "view_score_standard_deviation"
    ] = score_standard_deviation

    feature_values[
        "view_score_minimum"
    ] = score_minimum

    feature_values[
        "view_score_maximum"
    ] = score_maximum

    feature_values[
        "view_score_range"
    ] = (
        score_maximum
        - score_minimum
    )

    feature_values[
        "reliability_weighted_score"
    ] = reliability_weighted_score

    feature_values[
        "reliability_weighted_confidence"
    ] = reliability_weighted_confidence

    feature_values[
        "fraud_vote_count"
    ] = (
        calibrated_scores >= 0.5
    ).sum(axis=1)

    # Pairwise agreement and interaction
    for first_index in range(
        len(BRANCH_NAMES)
    ):
        for second_index in range(
            first_index + 1,
            len(BRANCH_NAMES)
        ):
            first_name = (
                BRANCH_NAMES[
                    first_index
                ].lower()
            )

            second_name = (
                BRANCH_NAMES[
                    second_index
                ].lower()
            )

            feature_values[
                f"{first_name}_{second_name}_absolute_difference"
            ] = np.abs(
                calibrated_scores[
                    :,
                    first_index
                ]
                - calibrated_scores[
                    :,
                    second_index
                ]
            )

            feature_values[
                f"{first_name}_{second_name}_interaction"
            ] = (
                calibrated_scores[
                    :,
                    first_index
                ]
                * calibrated_scores[
                    :,
                    second_index
                ]
            )

    feature_frame = pd.DataFrame(
        feature_values
    )

    if feature_frame.isna().any().any():
        raise ValueError(
            "Fusion features contain missing values."
        )

    return feature_frame


# ------------------------------------------------
# 6. Outer cross-fitted fusion
# ------------------------------------------------

row_count = len(fusion_data)
branch_count = len(BRANCH_NAMES)

oof_calibrated_scores = np.full(
    (row_count, branch_count),
    np.nan,
    dtype=np.float64
)

oof_reliability_weights = np.full(
    (row_count, branch_count),
    np.nan,
    dtype=np.float64
)

oof_weighted_score = np.full(
    row_count,
    np.nan,
    dtype=np.float64
)

oof_meta_probability = np.full(
    row_count,
    np.nan,
    dtype=np.float64
)

oof_fusion_probability = np.full(
    row_count,
    np.nan,
    dtype=np.float64
)

fold_metric_rows = []
reliability_rows = []
importance_rows = []

total_start_time = time.perf_counter()

for outer_fold in [1, 2, 3, 4, 5]:

    print("\n" + "=" * 72)
    print(
        f"RELIABILITY-AWARE FUSION — "
        f"FOLD {outer_fold}/5"
    )
    print("=" * 72)

    fold_start_time = time.perf_counter()

    outer_holdout_positions = np.where(
        fold_assignments == outer_fold
    )[0]

    outer_training_positions = np.where(
        fold_assignments != outer_fold
    )[0]

    if (
        set(
            campaign_groups[
                outer_training_positions
            ]
        )
        & set(
            campaign_groups[
                outer_holdout_positions
            ]
        )
    ):
        raise ValueError(
            "Campaign leakage detected."
        )

    outer_training_labels = labels[
        outer_training_positions
    ]

    training_fold_values = fold_assignments[
        outer_training_positions
    ]

    calibrated_training = np.full(
        (
            len(outer_training_positions),
            branch_count
        ),
        np.nan,
        dtype=np.float64
    )

    calibrated_holdout = np.full(
        (
            len(outer_holdout_positions),
            branch_count
        ),
        np.nan,
        dtype=np.float64
    )

    branch_skill_values = []

    for branch_index, branch_name in enumerate(
        BRANCH_NAMES
    ):

        branch_scores = raw_branch_scores[
            branch_name
        ]

        # Inner cross-fitted calibration
        for inner_fold in sorted(
            np.unique(training_fold_values)
        ):
            inner_calibration_local = np.where(
                training_fold_values
                != inner_fold
            )[0]

            inner_holdout_local = np.where(
                training_fold_values
                == inner_fold
            )[0]

            calibration_global_positions = (
                outer_training_positions[
                    inner_calibration_local
                ]
            )

            inner_holdout_global_positions = (
                outer_training_positions[
                    inner_holdout_local
                ]
            )

            inner_calibrator = (
                fit_platt_calibrator(
                    branch_name,
                    branch_scores[
                        calibration_global_positions
                    ],
                    labels[
                        calibration_global_positions
                    ]
                )
            )

            calibrated_training[
                inner_holdout_local,
                branch_index
            ] = apply_calibrator(
                inner_calibrator,
                branch_name,
                branch_scores[
                    inner_holdout_global_positions
                ]
            )

        # Fit on every outer-training row,
        # then calibrate the untouched outer fold
        full_calibrator = fit_platt_calibrator(
            branch_name,
            branch_scores[
                outer_training_positions
            ],
            outer_training_labels
        )

        calibrated_holdout[
            :,
            branch_index
        ] = apply_calibrator(
            full_calibrator,
            branch_name,
            branch_scores[
                outer_holdout_positions
            ]
        )

        training_pr_auc = (
            average_precision_score(
                outer_training_labels,
                branch_scores[
                    outer_training_positions
                ]
            )
        )

        training_prevalence = float(
            outer_training_labels.mean()
        )

        branch_skill = max(
            training_pr_auc
            - training_prevalence,
            1e-6
        )

        # Squaring gives more weight to
        # consistently stronger branches
        branch_skill_values.append(
            branch_skill ** 2
        )

        reliability_rows.append({
            "Outer_Fold": outer_fold,
            "Branch": branch_name,
            "Training_PR_AUC":
                training_pr_auc,
            "Training_Prevalence":
                training_prevalence,
            "Corrected_Skill":
                branch_skill,
            "Raw_Reliability_Value":
                branch_skill ** 2
        })

    if np.isnan(calibrated_training).any():
        raise ValueError(
            "Missing calibrated training scores."
        )

    if np.isnan(calibrated_holdout).any():
        raise ValueError(
            "Missing calibrated holdout scores."
        )

    reliability_weights = np.asarray(
        branch_skill_values,
        dtype=np.float64
    )

    reliability_weights /= (
        reliability_weights.sum()
    )

    for reliability_row in reliability_rows:
        if (
            reliability_row[
                "Outer_Fold"
            ]
            == outer_fold
        ):
            branch_position = (
                BRANCH_NAMES.index(
                    reliability_row[
                        "Branch"
                    ]
                )
            )

            reliability_row[
                "Normalized_Reliability_Weight"
            ] = reliability_weights[
                branch_position
            ]

    training_fusion_features = (
        build_fusion_features(
            calibrated_training,
            reliability_weights
        )
    )

    holdout_fusion_features = (
        build_fusion_features(
            calibrated_holdout,
            reliability_weights
        )
    )

    negative_count = int(
        (outer_training_labels == 0).sum()
    )

    positive_count = int(
        (outer_training_labels == 1).sum()
    )

    positive_weight = float(
        np.sqrt(
            negative_count
            / max(positive_count, 1)
        )
    )

    fusion_meta_model = CatBoostClassifier(
        iterations=400,
        depth=4,
        learning_rate=0.03,
        loss_function="Logloss",
        eval_metric="AUC",
        class_weights=[
            1.0,
            positive_weight
        ],
        l2_leaf_reg=10.0,
        random_strength=0.4,
        bootstrap_type="Bernoulli",
        subsample=0.85,
        random_seed=SEED + outer_fold,
        allow_writing_files=False,
        thread_count=-1,
        verbose=False
    )

    fusion_meta_model.fit(
        training_fusion_features,
        outer_training_labels,
        verbose=False
    )

    meta_holdout_probability = (
        fusion_meta_model.predict_proba(
            holdout_fusion_features
        )[:, 1]
    )

    reliability_holdout_score = (
        calibrated_holdout
        @ reliability_weights
    )

    final_holdout_probability = (
        META_MODEL_WEIGHT
        * meta_holdout_probability
        + RELIABILITY_SCORE_WEIGHT
        * reliability_holdout_score
    )

    oof_calibrated_scores[
        outer_holdout_positions
    ] = calibrated_holdout

    oof_reliability_weights[
        outer_holdout_positions
    ] = reliability_weights

    oof_weighted_score[
        outer_holdout_positions
    ] = reliability_holdout_score

    oof_meta_probability[
        outer_holdout_positions
    ] = meta_holdout_probability

    oof_fusion_probability[
        outer_holdout_positions
    ] = final_holdout_probability

    fold_metrics = evaluate_scores(
        labels[outer_holdout_positions],
        final_holdout_probability,
        threshold=0.5
    )

    fold_seconds = (
        time.perf_counter()
        - fold_start_time
    )

    fold_metric_rows.append({
        "OOF_Fold": outer_fold,
        "Training_Rows": len(
            outer_training_positions
        ),
        "Holdout_Rows": len(
            outer_holdout_positions
        ),
        "Holdout_Fraudulent": int(
            labels[
                outer_holdout_positions
            ].sum()
        ),
        "PR_AUC": fold_metrics["PR_AUC"],
        "ROC_AUC": fold_metrics["ROC_AUC"],
        "Precision_at_0_5":
            fold_metrics["Precision"],
        "Recall_at_0_5":
            fold_metrics["Recall"],
        "F1_at_0_5":
            fold_metrics["F1"],
        "MCC_at_0_5":
            fold_metrics["MCC"],
        "Training_Time_Seconds":
            fold_seconds,
        "Crossing_Campaign_Groups": 0
    })

    feature_importances = (
        fusion_meta_model
        .get_feature_importance()
    )

    for feature_name, importance in zip(
        training_fusion_features.columns,
        feature_importances
    ):
        importance_rows.append({
            "Outer_Fold": outer_fold,
            "Feature": feature_name,
            "Importance": importance
        })

    print(
        "Reliability weights:",
        {
            branch_name: round(
                reliability_weights[
                    branch_index
                ],
                4
            )
            for branch_index, branch_name
            in enumerate(BRANCH_NAMES)
        }
    )
    print(
        "PR-AUC:",
        round(fold_metrics["PR_AUC"], 4)
    )
    print(
        "F1 at threshold 0.5:",
        round(fold_metrics["F1"], 4)
    )
    print(
        "Fold time:",
        round(fold_seconds, 2),
        "seconds"
    )

    del (
        fusion_meta_model,
        training_fusion_features,
        holdout_fusion_features
    )

    gc.collect()


# ------------------------------------------------
# 7. Final OOF integrity checks
# ------------------------------------------------

required_output_arrays = [
    oof_calibrated_scores,
    oof_reliability_weights,
    oof_weighted_score,
    oof_meta_probability,
    oof_fusion_probability
]

if any(
    np.isnan(array).any()
    for array in required_output_arrays
):
    raise ValueError(
        "Missing fusion OOF values detected."
    )

total_training_seconds = (
    time.perf_counter()
    - total_start_time
)


# ------------------------------------------------
# 8. Pooled fusion metrics
# ------------------------------------------------

best_f1_threshold = find_best_threshold(
    labels,
    oof_fusion_probability
)

precision_guardrail_threshold = (
    find_best_threshold(
        labels,
        oof_fusion_probability,
        minimum_precision=0.90
    )
)

pooled_rows = []

for threshold_type, threshold in [
    ("Default 0.50", 0.50),
    (
        "OOF F1 Optimized",
        best_f1_threshold
    ),
    (
        "Precision >= 0.90",
        precision_guardrail_threshold
    )
]:
    metric_row = evaluate_scores(
        labels,
        oof_fusion_probability,
        threshold
    )

    metric_row[
        "Threshold_Type"
    ] = threshold_type

    pooled_rows.append(metric_row)

pooled_metrics = pd.DataFrame(
    pooled_rows
)[
    [
        "Threshold_Type",
        "Threshold",
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "Specificity",
        "Balanced_Accuracy",
        "PR_AUC",
        "ROC_AUC",
        "MCC",
        "TN",
        "FP",
        "FN",
        "TP"
    ]
]

fold_metrics_table = pd.DataFrame(
    fold_metric_rows
)

reliability_table = pd.DataFrame(
    reliability_rows
)

average_reliability = (
    reliability_table
    .groupby("Branch", as_index=False)
    .agg(
        Mean_Training_PR_AUC=(
            "Training_PR_AUC",
            "mean"
        ),
        Mean_Reliability_Weight=(
            "Normalized_Reliability_Weight",
            "mean"
        )
    )
    .sort_values(
        "Mean_Reliability_Weight",
        ascending=False
    )
)

importance_table = (
    pd.DataFrame(importance_rows)
    .groupby("Feature", as_index=False)
    .agg(
        Mean_Importance=(
            "Importance",
            "mean"
        )
    )
    .sort_values(
        "Mean_Importance",
        ascending=False
    )
)


# ------------------------------------------------
# 9. Compare fusion against all branches
# ------------------------------------------------

comparison_rows = []

comparison_scores = {
    "Lexical": raw_branch_scores["Lexical"],
    "Metadata": raw_branch_scores["Metadata"],
    "Semantic": raw_branch_scores["Semantic"],
    "Campaign": raw_branch_scores["Campaign"],
    "SAGE-FJD Fusion":
        oof_fusion_probability
}

for model_name, model_scores in (
    comparison_scores.items()
):
    model_threshold = find_best_threshold(
        labels,
        model_scores
    )

    model_metrics = evaluate_scores(
        labels,
        model_scores,
        model_threshold
    )

    comparison_rows.append({
        "Model": model_name,
        "Best_Threshold":
            model_threshold,
        "Accuracy":
            model_metrics["Accuracy"],
        "Precision":
            model_metrics["Precision"],
        "Recall":
            model_metrics["Recall"],
        "F1":
            model_metrics["F1"],
        "PR_AUC":
            model_metrics["PR_AUC"],
        "ROC_AUC":
            model_metrics["ROC_AUC"],
        "MCC":
            model_metrics["MCC"]
    })

comparison_table = (
    pd.DataFrame(comparison_rows)
    .sort_values(
        "PR_AUC",
        ascending=False
    )
    .reset_index(drop=True)
)


# ------------------------------------------------
# 10. Save Step 7 artifacts
# ------------------------------------------------

fusion_predictions = oof_manifest.copy()

for branch_index, branch_name in enumerate(
    BRANCH_NAMES
):
    normalized_name = branch_name.lower()

    fusion_predictions[
        f"{normalized_name}_calibrated"
    ] = oof_calibrated_scores[
        :,
        branch_index
    ]

    fusion_predictions[
        f"{normalized_name}_reliability_weight"
    ] = oof_reliability_weights[
        :,
        branch_index
    ]

fusion_predictions[
    "reliability_weighted_probability"
] = oof_weighted_score

fusion_predictions[
    "fusion_meta_probability"
] = oof_meta_probability

fusion_predictions[
    "sage_fjd_fusion_probability"
] = oof_fusion_probability

prediction_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_oof_predictions.csv"
)

fold_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_oof_fold_metrics.csv"
)

pooled_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_oof_pooled_metrics.csv"
)

reliability_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_branch_reliability.csv"
)

comparison_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_branch_comparison.csv"
)

importance_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_feature_importance.csv"
)

configuration_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_fusion_configuration.json"
)

fusion_predictions.to_csv(
    prediction_path,
    index=False
)

fold_metrics_table.to_csv(
    fold_metrics_path,
    index=False
)

pooled_metrics.to_csv(
    pooled_metrics_path,
    index=False
)

reliability_table.to_csv(
    reliability_path,
    index=False
)

comparison_table.to_csv(
    comparison_path,
    index=False
)

importance_table.to_csv(
    importance_path,
    index=False
)


def file_sha256(file_path):
    checksum = hashlib.sha256()

    with open(file_path, "rb") as file_handle:
        for block in iter(
            lambda: file_handle.read(
                1024 * 1024
            ),
            b""
        ):
            checksum.update(block)

    return checksum.hexdigest()


configuration = {
    "created_utc":
        datetime.now(timezone.utc).isoformat(),
    "experiment":
        "SAGE-FJD",
    "step":
        7,
    "fusion":
        "Cross-fitted reliability-aware stacking",
    "branches":
        BRANCH_NAMES,
    "calibration":
        "Nested fold-local Platt calibration",
    "reliability_measure":
        "Squared PR-AUC skill above prevalence",
    "meta_model":
        "CatBoostClassifier",
    "meta_model_weight":
        META_MODEL_WEIGHT,
    "reliability_score_weight":
        RELIABILITY_SCORE_WEIGHT,
    "pooled_oof_pr_auc":
        float(
            average_precision_score(
                labels,
                oof_fusion_probability
            )
        ),
    "best_oof_f1_threshold":
        best_f1_threshold,
    "training_seconds":
        total_training_seconds,
    "campaign_overlap":
        0,
    "validation_rows_used":
        0,
    "test_rows_used":
        0,
    "prediction_sha256":
        file_sha256(prediction_path)
}

with open(
    configuration_path,
    "w",
    encoding="utf-8"
) as configuration_file:
    json.dump(
        configuration,
        configuration_file,
        indent=2
    )

checkpoint_zip = Path(
    shutil.make_archive(
        "/kaggle/working/"
        "sage_fjd_step_07_checkpoint",
        "zip",
        root_dir=PROJECT_DIRECTORY
    )
)


# ------------------------------------------------
# 11. Display final results
# ------------------------------------------------

print("\nFUSION OOF FOLD RESULTS")
display(
    fold_metrics_table.round(4)
)

print("\nPOOLED FUSION OOF RESULTS")
display(
    pooled_metrics.round(4)
)

print("\nBRANCH RELIABILITY")
display(
    average_reliability.round(4)
)

print("\nOOF BRANCH COMPARISON")
display(
    comparison_table.round(4)
)

print("\nTOP FUSION FEATURES")
display(
    importance_table.head(15).round(4)
)

fusion_beats_best_branch = (
    average_precision_score(
        labels,
        oof_fusion_probability
    )
    >
    max(
        average_precision_score(
            labels,
            raw_branch_scores[
                branch_name
            ]
        )
        for branch_name in BRANCH_NAMES
    )
)

print("\n" + "=" * 72)
print("SAGE-FJD PROPOSED MODEL STEP 7 COMPLETED")
print("=" * 72)
print(
    "Total time:",
    round(total_training_seconds / 60, 2),
    "minutes"
)
print(
    "Pooled fusion PR-AUC:",
    round(
        average_precision_score(
            labels,
            oof_fusion_probability
        ),
        4
    )
)
print(
    "Best fusion F1 threshold:",
    round(best_f1_threshold, 4)
)
print(
    "Fusion beats best individual OOF branch:",
    fusion_beats_best_branch
)
print("Campaign overlap: 0")
print("Validation rows used: 0")
print("Test rows used: 0")
print("Predictions:", prediction_path)
print("Checkpoint ZIP:", checkpoint_zip)
print(
    "Next step: freeze the fusion design and "
    "prepare locked validation evaluation."
)
print("=" * 72)