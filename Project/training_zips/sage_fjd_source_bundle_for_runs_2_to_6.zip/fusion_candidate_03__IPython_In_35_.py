# ============================================================
# SAGE-FJD PROPOSED MODEL — STEP 1
# Freeze architecture, benchmark targets and leakage rules
# No training or test evaluation is performed.
# ============================================================

from pathlib import Path
import hashlib
import json
import re

import pandas as pd
from IPython.display import display


# ------------------------------------------------------------
# 1. Proposed-model workspace
# ------------------------------------------------------------

PROJECT_NAME = "SAGE-FJD"

PROJECT_DIR = Path(
    "/kaggle/working/proposed_sage_fjd"
)

PROJECT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ------------------------------------------------------------
# 2. Helper functions
# ------------------------------------------------------------

def normalize_name(value):

    return re.sub(
        r"[^a-z0-9]+",
        "",
        str(value).lower()
    )


def file_sha256(path):

    sha256 = hashlib.sha256()

    with open(path, "rb") as file:

        while True:

            block = file.read(
                8 * 1024 * 1024
            )

            if not block:
                break

            sha256.update(block)

    return sha256.hexdigest()


def locate_column(
    dataframe,
    accepted_names
):

    normalized = {
        normalize_name(column): column
        for column in dataframe.columns
    }

    for accepted_name in accepted_names:

        key = normalize_name(
            accepted_name
        )

        if key in normalized:
            return normalized[key]

    return None


# ------------------------------------------------------------
# 3. Locate dataset
# ------------------------------------------------------------

dataset_candidates = list(
    Path("/kaggle/input").rglob(
        "fake_job_postings.csv"
    )
)

if not dataset_candidates:
    raise FileNotFoundError(
        "fake_job_postings.csv was not found."
    )

dataset_candidates.sort(
    key=lambda path:
    "real-or-fake-fake-jobposting-prediction"
    not in str(path).lower()
)

DATASET_PATH = dataset_candidates[0]

dataset_columns = pd.read_csv(
    DATASET_PATH,
    nrows=0
).columns.tolist()

if "fraudulent" not in dataset_columns:
    raise ValueError(
        "Target column 'fraudulent' is missing."
    )


# ------------------------------------------------------------
# 4. Locate locked split manifest
# ------------------------------------------------------------

manifest_candidates = [
    Path(
        "/kaggle/working/"
        "emscad_split_manifest.csv"
    )
]

manifest_candidates += list(
    Path("/kaggle/input").rglob(
        "emscad_split_manifest.csv"
    )
)

MANIFEST_PATH = next(
    (
        path
        for path in manifest_candidates
        if path.exists()
    ),
    None
)

if MANIFEST_PATH is None:
    raise FileNotFoundError(
        "Locked EMSCAD split manifest "
        "was not found."
    )

manifest = pd.read_csv(
    MANIFEST_PATH
)

if len(manifest) != 17880:
    raise ValueError(
        "Locked manifest must contain "
        "17,880 rows."
    )


# ------------------------------------------------------------
# 5. Locate final baseline leaderboard
# ------------------------------------------------------------

leaderboard_candidates = [
    Path(
        "/kaggle/working/"
        "final_baseline_comparison/"
        "optimized_baseline_leaderboard.csv"
    )
]

leaderboard_candidates += list(
    Path("/kaggle/input").rglob(
        "optimized_baseline_leaderboard.csv"
    )
)

LEADERBOARD_PATH = next(
    (
        path
        for path in leaderboard_candidates
        if path.exists()
    ),
    None
)

if LEADERBOARD_PATH is None:
    raise FileNotFoundError(
        "Final optimized baseline leaderboard "
        "was not found."
    )

leaderboard = pd.read_csv(
    LEADERBOARD_PATH
)


# ------------------------------------------------------------
# 6. Standardize leaderboard columns
# ------------------------------------------------------------

column_options = {
    "Protocol": [
        "Protocol",
    ],

    "Baseline_ID": [
        "Baseline_ID",
        "Baseline ID",
    ],

    "Model": [
        "Model",
    ],

    "Threshold": [
        "Threshold",
        "Best Threshold",
    ],

    "Accuracy": [
        "Accuracy",
    ],

    "Precision": [
        "Precision",
    ],

    "Recall": [
        "Recall",
    ],

    "F1": [
        "F1",
        "F1 Score",
        "F1_Score",
    ],

    "Balanced_Accuracy": [
        "Balanced Accuracy",
        "Balanced_Accuracy",
    ],

    "PR_AUC": [
        "PR AUC",
        "PR_AUC",
        "PR AUC AP",
        "PR_AUC_AP",
    ],

    "ROC_AUC": [
        "ROC AUC",
        "ROC_AUC",
    ],

    "MCC": [
        "MCC",
    ],
}

resolved_columns = {}

for standard_name, alternatives in (
    column_options.items()
):

    resolved = locate_column(
        leaderboard,
        alternatives
    )

    if resolved is None:
        raise ValueError(
            f"Leaderboard column missing: "
            f"{standard_name}"
        )

    resolved_columns[
        standard_name
    ] = resolved


standardized_leaderboard = pd.DataFrame({
    standard_name:
        leaderboard[source_column]

    for standard_name, source_column
    in resolved_columns.items()
})

numeric_columns = [
    "Threshold",
    "Accuracy",
    "Precision",
    "Recall",
    "F1",
    "Balanced_Accuracy",
    "PR_AUC",
    "ROC_AUC",
    "MCC",
]

for column in numeric_columns:

    standardized_leaderboard[
        column
    ] = pd.to_numeric(
        standardized_leaderboard[
            column
        ],
        errors="coerce"
    )


# ------------------------------------------------------------
# 7. Use leakage-safe results as primary benchmarks
# ------------------------------------------------------------

leakage_safe_results = (
    standardized_leaderboard[
        standardized_leaderboard[
            "Protocol"
        ]
        .astype(str)
        .map(normalize_name)
        .str.contains("leakagesafe")
    ]
    .copy()
)

if len(leakage_safe_results) != 7:
    raise ValueError(
        "Expected seven leakage-safe "
        "baseline results."
    )

benchmark_metrics = [
    "Accuracy",
    "Precision",
    "Recall",
    "F1",
    "Balanced_Accuracy",
    "PR_AUC",
    "ROC_AUC",
    "MCC",
]

benchmark_rows = []

for metric in benchmark_metrics:

    winner_index = (
        leakage_safe_results[
            metric
        ].idxmax()
    )

    winner = (
        leakage_safe_results.loc[
            winner_index
        ]
    )

    benchmark_rows.append({
        "Metric": metric,

        "Current_Best_Score":
            float(winner[metric]),

        "Baseline_ID":
            str(winner["Baseline_ID"]),

        "Winning_Model":
            str(winner["Model"]),

        "Threshold":
            float(winner["Threshold"]),
    })

benchmark_table = pd.DataFrame(
    benchmark_rows
)

benchmark_table.to_csv(
    PROJECT_DIR
    / "locked_baseline_targets.csv",
    index=False
)


# ------------------------------------------------------------
# 8. Define honest proposed-model targets
# ------------------------------------------------------------

def benchmark_score(metric):

    return float(
        benchmark_table.loc[
            benchmark_table[
                "Metric"
            ] == metric,
            "Current_Best_Score"
        ].iloc[0]
    )


target_rows = [
    {
        "Metric": "F1",
        "Current_Best":
            benchmark_score("F1"),
        "SAGE_FJD_Goal":
            "Must exceed",
        "Priority":
            "Primary",
    },
    {
        "Metric": "PR_AUC",
        "Current_Best":
            benchmark_score("PR_AUC"),
        "SAGE_FJD_Goal":
            "Must exceed",
        "Priority":
            "Primary",
    },
    {
        "Metric": "MCC",
        "Current_Best":
            benchmark_score("MCC"),
        "SAGE_FJD_Goal":
            "Must exceed",
        "Priority":
            "Primary",
    },
    {
        "Metric": "Recall",
        "Current_Best":
            benchmark_score("Recall"),
        "SAGE_FJD_Goal":
            "Try to exceed",
        "Priority":
            "Secondary",
    },
    {
        "Metric": "Accuracy",
        "Current_Best":
            benchmark_score("Accuracy"),
        "SAGE_FJD_Goal":
            "Try to exceed",
        "Priority":
            "Secondary",
    },
    {
        "Metric": "Precision",
        "Current_Best":
            benchmark_score("Precision"),
        "SAGE_FJD_Goal":
            "Maintain >= 0.90",
        "Priority":
            "Guardrail",
    },
    {
        "Metric": "ROC_AUC",
        "Current_Best":
            benchmark_score("ROC_AUC"),
        "SAGE_FJD_Goal":
            "Monitor",
        "Priority":
            "Supporting",
    },
]

target_table = pd.DataFrame(
    target_rows
)

target_table.to_csv(
    PROJECT_DIR
    / "sage_fjd_success_targets.csv",
    index=False
)


# ------------------------------------------------------------
# 9. Identify campaign-group column
# ------------------------------------------------------------

normalized_manifest_columns = {
    normalize_name(column): column
    for column in manifest.columns
}

safe_split_column = (
    normalized_manifest_columns.get(
        "leakagesafesplit"
    )
)

standard_split_column = (
    normalized_manifest_columns.get(
        "standardsplit"
    )
)

campaign_group_candidates = [
    column
    for normalized, column
    in normalized_manifest_columns.items()
    if (
        "campaign" in normalized
        and "group" in normalized
    )
]

campaign_group_column = (
    campaign_group_candidates[0]
    if campaign_group_candidates
    else None
)

if safe_split_column is None:
    raise ValueError(
        "leakage_safe_split column "
        "was not found."
    )


# ------------------------------------------------------------
# 10. Verify locked split counts
# ------------------------------------------------------------

safe_counts = (
    manifest[safe_split_column]
    .astype(str)
    .str.strip()
    .str.lower()
    .replace({
        "val": "validation"
    })
    .value_counts()
    .to_dict()
)

expected_safe_counts = {
    "train": 12525,
    "validation": 2675,
    "test": 2680,
}

if safe_counts != expected_safe_counts:
    raise ValueError(
        "Leakage-safe split changed.\n"
        f"Expected: {expected_safe_counts}\n"
        f"Actual: {safe_counts}"
    )


# ------------------------------------------------------------
# 11. Freeze SAGE-FJD architecture
# ------------------------------------------------------------

experiment_contract = {
    "project_name":
        "SAGE-FJD",

    "full_name":
        (
            "Section-Aware Group-Isolated "
            "Evidence Fusion for Fraudulent "
            "Job Detection"
        ),

    "dataset":
        str(DATASET_PATH),

    "dataset_rows":
        17880,

    "target":
        "fraudulent",

    "primary_protocol":
        "Leakage-Safe",

    "locked_manifest":
        str(MANIFEST_PATH),

    "manifest_sha256":
        file_sha256(MANIFEST_PATH),

    "baseline_leaderboard":
        str(LEADERBOARD_PATH),

    "leaderboard_sha256":
        file_sha256(LEADERBOARD_PATH),

    "internal_training_protocol": {
        "method":
            "5-fold group-aware out-of-fold training",

        "data_used":
            "Leakage-safe training split only",

        "grouping":
            (
                campaign_group_column
                if campaign_group_column
                else
                "Reconstruct campaign groups "
                "from normalized templates"
            ),

        "validation_rows_used_for_fitting":
            False,

        "test_rows_used":
            False,
    },

    "evidence_views": {
        "lexical_view":
            (
                "Word and character TF-IDF "
                "with Linear SVM"
            ),

        "structural_view":
            (
                "Metadata, missingness, risk "
                "signals and CatBoost"
            ),

        "semantic_view":
            (
                "Separate semantic encoding "
                "of title, company profile, "
                "description, requirements "
                "and benefits"
            ),

        "campaign_view":
            (
                "Fold-local template reuse "
                "and campaign novelty signals"
            ),
    },

    "fusion_method":
        (
            "Reliability-aware meta learner "
            "trained only on out-of-fold "
            "branch predictions"
        ),

    "calibration":
        (
            "Probability calibration fitted "
            "using training OOF predictions"
        ),

    "threshold_policy":
        (
            "Final decision threshold selected "
            "using leakage-safe validation only "
            "after architecture is frozen"
        ),

    "primary_metrics": [
        "F1",
        "PR_AUC",
        "MCC",
    ],

    "guardrails": {
        "minimum_precision": 0.90,
        "minimum_recall": 0.80,
    },

    "novelty_components": [
        "Campaign-disjoint evaluation",
        "Section-aware long-text representation",
        "Fold-local campaign risk features",
        "Out-of-fold multi-view evidence fusion",
        "Reliability-aware branch weighting",
    ],

    "test_policy":
        (
            "The locked test set must not be "
            "loaded, tokenized, predicted or "
            "evaluated until the complete model "
            "and threshold are frozen."
        ),

    "test_evaluated":
        False,
}

with open(
    PROJECT_DIR
    / "sage_fjd_experiment_contract.json",
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        experiment_contract,
        file,
        indent=2
    )


# ------------------------------------------------------------
# 12. Display frozen experiment
# ------------------------------------------------------------

print(
    "\nCURRENT LEAKAGE-SAFE "
    "BENCHMARKS TO BEAT"
)

display(
    benchmark_table.round(4)
)

print(
    "\nSAGE-FJD SUCCESS TARGETS"
)

display(
    target_table.round(4)
)

architecture_table = pd.DataFrame([
    {
        "View": "Lexical",
        "Evidence":
            "Word + character patterns",
    },
    {
        "View": "Structural",
        "Evidence":
            "Metadata + missingness + risk signals",
    },
    {
        "View": "Semantic",
        "Evidence":
            "Each long-text section separately",
    },
    {
        "View": "Campaign",
        "Evidence":
            "Template reuse and novelty",
    },
    {
        "View": "Fusion",
        "Evidence":
            "Group-aware OOF predictions",
    },
])

print(
    "\nFROZEN SAGE-FJD ARCHITECTURE"
)

display(architecture_table)

print("\n" + "=" * 74)
print(
    "SAGE-FJD PROPOSED MODEL "
    "STEP 1 COMPLETED"
)
print(
    "Project directory:",
    PROJECT_DIR
)
print(
    "Campaign group column:",
    (
        campaign_group_column
        if campaign_group_column
        else "Must be reconstructed"
    )
)
print(
    "No model training was performed."
)
print(
    "Validation and test features "
    "were not loaded."
)
print(
    "Locked test set remains untouched."
)
print(
    "Next step: create five "
    "group-isolated OOF folds."
)
print("=" * 74)