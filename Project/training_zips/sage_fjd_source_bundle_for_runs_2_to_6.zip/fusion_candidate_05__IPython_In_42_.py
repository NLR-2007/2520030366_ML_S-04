# ================================================================
# SAGE-FJD — STEP 6
# FOLD-LOCAL CAMPAIGN NOVELTY AND RISK OOF BRANCH
# ================================================================

from pathlib import Path
from datetime import datetime, timezone
import gc
import hashlib
import html
import json
import re
import shutil
import time

import numpy as np
import pandas as pd

from catboost import CatBoostClassifier
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score
)

from IPython.display import display


# ------------------------------------------------
# 1. Configuration
# ------------------------------------------------

SEED = 42
SMOOTHING_STRENGTH = 5.0

PROJECT_DIRECTORY = Path(
    "/kaggle/working/proposed_sage_fjd"
)

OOF_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_manifest.csv"
)

SEMANTIC_CACHE_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_section_embeddings.npz"
)

SECTION_FIELDS = [
    "title",
    "company_profile",
    "description",
    "requirements",
    "benefits"
]

EMBEDDING_DIMENSION = 384
SECTION_BLOCK_SIZE = EMBEDDING_DIMENSION * 2

if not OOF_MANIFEST_PATH.is_file():
    raise FileNotFoundError(
        "OOF manifest was not found."
    )

if not SEMANTIC_CACHE_PATH.is_file():
    raise FileNotFoundError(
        "Step 5 semantic embedding cache "
        "was not found."
    )


# ------------------------------------------------
# 2. Locate dataset
# ------------------------------------------------

dataset_candidates = [
    Path(
        "/kaggle/input/datasets/shivamb/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    ),
    Path(
        "/kaggle/input/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    )
]

dataset_candidates.extend(
    Path("/kaggle/input").rglob(
        "fake_job_postings.csv"
    )
)

dataset_candidates = [
    path
    for path in dataset_candidates
    if path.is_file()
]

if not dataset_candidates:
    raise FileNotFoundError(
        "fake_job_postings.csv was not found."
    )

DATASET_PATH = dataset_candidates[0]


# ------------------------------------------------
# 3. Load and validate manifest
# ------------------------------------------------

oof_manifest = pd.read_csv(
    OOF_MANIFEST_PATH
)

required_columns = [
    "source_row_index",
    "fraudulent",
    "campaign_group",
    "oof_fold",
    "source_split"
]

missing_columns = [
    column
    for column in required_columns
    if column not in oof_manifest.columns
]

if missing_columns:
    raise ValueError(
        "Missing OOF columns: "
        + ", ".join(missing_columns)
    )

if len(oof_manifest) != 12525:
    raise ValueError(
        "Expected 12,525 training rows."
    )

if int(oof_manifest["fraudulent"].sum()) != 609:
    raise ValueError(
        "Expected 609 fraudulent rows."
    )

if not (
    oof_manifest["source_split"]
    .astype(str)
    .str.lower()
    .eq("train")
    .all()
):
    raise ValueError(
        "Non-training rows exist."
    )

campaign_crossing_count = int(
    (
        oof_manifest
        .groupby("campaign_group")["oof_fold"]
        .nunique()
        > 1
    ).sum()
)

if campaign_crossing_count != 0:
    raise ValueError(
        "Campaign groups cross OOF folds."
    )


# ------------------------------------------------
# 4. Load training text only
# ------------------------------------------------

wanted_source_rows = set(
    oof_manifest["source_row_index"]
    .astype(int)
    .tolist()
)

retained_chunks = []
row_cursor = 0

print("=" * 72)
print("SAGE-FJD STEP 6 — CAMPAIGN NOVELTY/RISK BRANCH")
print("=" * 72)
print("Dataset:", DATASET_PATH)
print("Loading leakage-safe training templates...")

for dataset_chunk in pd.read_csv(
    DATASET_PATH,
    usecols=SECTION_FIELDS,
    chunksize=2000
):
    chunk_rows = np.arange(
        row_cursor,
        row_cursor + len(dataset_chunk)
    )

    keep_mask = np.isin(
        chunk_rows,
        list(wanted_source_rows)
    )

    if keep_mask.any():
        retained = (
            dataset_chunk.loc[keep_mask]
            .copy()
            .reset_index(drop=True)
        )

        retained.insert(
            0,
            "source_row_index",
            chunk_rows[keep_mask]
        )

        retained_chunks.append(retained)

    row_cursor += len(dataset_chunk)

training_text = pd.concat(
    retained_chunks,
    ignore_index=True
)

del retained_chunks
gc.collect()

training_data = (
    oof_manifest
    .merge(
        training_text,
        on="source_row_index",
        how="left",
        validate="one_to_one"
    )
    .sort_values("source_row_index")
    .reset_index(drop=True)
)

if len(training_data) != 12525:
    raise ValueError(
        "Training-text count mismatch."
    )


# ------------------------------------------------
# 5. Normalize reusable templates
# ------------------------------------------------

def normalize_template(value):
    if pd.isna(value):
        return ""

    text = html.unescape(
        str(value)
    ).lower()

    text = re.sub(
        r"<[^>]+>",
        " ",
        text
    )

    text = re.sub(
        r"https?://\S+|www\.\S+",
        " __url__ ",
        text
    )

    text = re.sub(
        r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b",
        " __email__ ",
        text
    )

    text = re.sub(
        r"\d+",
        " 0 ",
        text
    )

    text = re.sub(
        r"[^a-z0-9_]+",
        " ",
        text
    )

    text = re.sub(
        r"\s+",
        " ",
        text
    ).strip()

    return text


normalized_templates = {}

for section in SECTION_FIELDS:
    normalized_templates[section] = (
        training_data[section]
        .map(normalize_template)
        .to_numpy()
    )


# ------------------------------------------------
# 6. Load semantic section means
# ------------------------------------------------

semantic_cache = np.load(
    SEMANTIC_CACHE_PATH
)

cached_source_rows = semantic_cache[
    "source_row_index"
].astype(int)

expected_source_rows = (
    training_data["source_row_index"]
    .astype(int)
    .to_numpy()
)

if not np.array_equal(
    cached_source_rows,
    expected_source_rows
):
    raise ValueError(
        "Semantic cache does not match "
        "the OOF manifest."
    )

semantic_features = semantic_cache[
    "semantic_features"
].astype(np.float32)

expected_minimum_columns = (
    len(SECTION_FIELDS)
    * SECTION_BLOCK_SIZE
)

if (
    semantic_features.shape[1]
    < expected_minimum_columns
):
    raise ValueError(
        "Semantic cache has insufficient columns."
    )

section_mean_embeddings = {}

for section_index, section in enumerate(
    SECTION_FIELDS
):
    section_start = (
        section_index
        * SECTION_BLOCK_SIZE
    )

    section_end = (
        section_start
        + EMBEDDING_DIMENSION
    )

    section_mean = semantic_features[
        :,
        section_start:section_end
    ].astype(np.float32)

    section_norm = np.linalg.norm(
        section_mean,
        axis=1,
        keepdims=True
    )

    section_mean_embeddings[section] = (
        section_mean
        / np.clip(
            section_norm,
            1e-8,
            None
        )
    ).astype(np.float32)

del semantic_features
gc.collect()


# ------------------------------------------------
# 7. Fixed arrays
# ------------------------------------------------

labels = (
    training_data["fraudulent"]
    .astype(int)
    .to_numpy()
)

groups = (
    training_data["campaign_group"]
    .astype(str)
    .to_numpy()
)

outer_folds = (
    training_data["oof_fold"]
    .astype(int)
    .to_numpy()
)


# ------------------------------------------------
# 8. Fold-local campaign feature builder
# ------------------------------------------------

def build_campaign_features(
    reference_positions,
    target_positions
):
    reference_positions = np.asarray(
        reference_positions,
        dtype=int
    )

    target_positions = np.asarray(
        target_positions,
        dtype=int
    )

    reference_labels = labels[
        reference_positions
    ]

    reference_groups = groups[
        reference_positions
    ]

    base_fraud_rate = float(
        reference_labels.mean()
    )

    feature_values = {}
    template_risk_columns = []
    template_support_columns = []

    for section in SECTION_FIELDS:

        reference_templates = (
            normalized_templates[section][
                reference_positions
            ]
        )

        target_templates = (
            normalized_templates[section][
                target_positions
            ]
        )

        reference_table = pd.DataFrame({
            "template": reference_templates,
            "campaign_group":
                reference_groups,
            "fraudulent":
                reference_labels
        })

        reference_table = reference_table[
            reference_table["template"].ne("")
        ].copy()

        if reference_table.empty:

            row_support = np.zeros(
                len(target_positions),
                dtype=np.float32
            )

            group_support = np.zeros(
                len(target_positions),
                dtype=np.float32
            )

            smoothed_risk = np.full(
                len(target_positions),
                base_fraud_rate,
                dtype=np.float32
            )

        else:

            row_statistics = (
                reference_table
                .groupby("template")
                .agg(
                    row_support=(
                        "fraudulent",
                        "size"
                    )
                )
            )

            group_table = (
                reference_table
                .groupby(
                    [
                        "template",
                        "campaign_group"
                    ],
                    as_index=False
                )
                .agg(
                    group_fraud_rate=(
                        "fraudulent",
                        "mean"
                    )
                )
            )

            group_statistics = (
                group_table
                .groupby("template")
                .agg(
                    group_support=(
                        "campaign_group",
                        "size"
                    ),
                    group_fraud_sum=(
                        "group_fraud_rate",
                        "sum"
                    )
                )
            )

            template_statistics = (
                row_statistics
                .join(
                    group_statistics,
                    how="outer"
                )
                .fillna(0)
            )

            template_statistics[
                "smoothed_fraud_risk"
            ] = (
                template_statistics[
                    "group_fraud_sum"
                ]
                + (
                    SMOOTHING_STRENGTH
                    * base_fraud_rate
                )
            ) / (
                template_statistics[
                    "group_support"
                ]
                + SMOOTHING_STRENGTH
            )

            row_support_map = (
                template_statistics[
                    "row_support"
                ].to_dict()
            )

            group_support_map = (
                template_statistics[
                    "group_support"
                ].to_dict()
            )

            risk_map = (
                template_statistics[
                    "smoothed_fraud_risk"
                ].to_dict()
            )

            row_support = np.asarray(
                [
                    row_support_map.get(
                        template,
                        0.0
                    )
                    for template in target_templates
                ],
                dtype=np.float32
            )

            group_support = np.asarray(
                [
                    group_support_map.get(
                        template,
                        0.0
                    )
                    for template in target_templates
                ],
                dtype=np.float32
            )

            smoothed_risk = np.asarray(
                [
                    risk_map.get(
                        template,
                        base_fraud_rate
                    )
                    for template in target_templates
                ],
                dtype=np.float32
            )

        seen_template = (
            group_support > 0
        ).astype(np.float32)

        risk_difference = (
            smoothed_risk
            - base_fraud_rate
        ).astype(np.float32)

        feature_values[
            f"{section}_template_seen"
        ] = seen_template

        feature_values[
            f"{section}_row_support_log"
        ] = np.log1p(
            row_support
        ).astype(np.float32)

        feature_values[
            f"{section}_group_support_log"
        ] = np.log1p(
            group_support
        ).astype(np.float32)

        feature_values[
            f"{section}_smoothed_fraud_risk"
        ] = smoothed_risk

        feature_values[
            f"{section}_risk_minus_base"
        ] = risk_difference

        template_risk_columns.append(
            risk_difference
        )

        template_support_columns.append(
            np.log1p(group_support)
            .astype(np.float32)
        )

        # Semantic fraud/genuine prototype similarity
        reference_embeddings = (
            section_mean_embeddings[section][
                reference_positions
            ]
        )

        target_embeddings = (
            section_mean_embeddings[section][
                target_positions
            ]
        )

        fraud_centroid = (
            reference_embeddings[
                reference_labels == 1
            ].mean(axis=0)
        )

        genuine_centroid = (
            reference_embeddings[
                reference_labels == 0
            ].mean(axis=0)
        )

        fraud_centroid /= max(
            float(
                np.linalg.norm(
                    fraud_centroid
                )
            ),
            1e-8
        )

        genuine_centroid /= max(
            float(
                np.linalg.norm(
                    genuine_centroid
                )
            ),
            1e-8
        )

        fraud_similarity = (
            target_embeddings
            @ fraud_centroid
        ).astype(np.float32)

        genuine_similarity = (
            target_embeddings
            @ genuine_centroid
        ).astype(np.float32)

        feature_values[
            f"{section}_fraud_similarity"
        ] = fraud_similarity

        feature_values[
            f"{section}_genuine_similarity"
        ] = genuine_similarity

        feature_values[
            f"{section}_similarity_difference"
        ] = (
            fraud_similarity
            - genuine_similarity
        ).astype(np.float32)

    risk_matrix = np.column_stack(
        template_risk_columns
    )

    support_matrix = np.column_stack(
        template_support_columns
    )

    feature_values[
        "reference_base_fraud_rate"
    ] = np.full(
        len(target_positions),
        base_fraud_rate,
        dtype=np.float32
    )

    feature_values[
        "template_risk_mean"
    ] = risk_matrix.mean(
        axis=1
    ).astype(np.float32)

    feature_values[
        "template_risk_max"
    ] = risk_matrix.max(
        axis=1
    ).astype(np.float32)

    feature_values[
        "template_risk_std"
    ] = risk_matrix.std(
        axis=1
    ).astype(np.float32)

    feature_values[
        "template_support_mean"
    ] = support_matrix.mean(
        axis=1
    ).astype(np.float32)

    feature_values[
        "template_support_max"
    ] = support_matrix.max(
        axis=1
    ).astype(np.float32)

    feature_frame = pd.DataFrame(
        feature_values
    )

    feature_frame = feature_frame.replace(
        [np.inf, -np.inf],
        0
    ).fillna(0)

    return feature_frame


# ------------------------------------------------
# 9. Metric helpers
# ------------------------------------------------

def evaluate_scores(
    true_labels,
    probabilities,
    threshold
):
    predictions = (
        probabilities >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        true_labels,
        predictions,
        labels=[0, 1]
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "Threshold": float(threshold),
        "Accuracy": accuracy_score(
            true_labels,
            predictions
        ),
        "Precision": precision_score(
            true_labels,
            predictions,
            zero_division=0
        ),
        "Recall": recall_score(
            true_labels,
            predictions,
            zero_division=0
        ),
        "F1": f1_score(
            true_labels,
            predictions,
            zero_division=0
        ),
        "Specificity": specificity,
        "Balanced_Accuracy":
            balanced_accuracy_score(
                true_labels,
                predictions
            ),
        "PR_AUC": average_precision_score(
            true_labels,
            probabilities
        ),
        "ROC_AUC": roc_auc_score(
            true_labels,
            probabilities
        ),
        "MCC": matthews_corrcoef(
            true_labels,
            predictions
        ),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp)
    }


def find_best_threshold(
    true_labels,
    probabilities,
    minimum_precision=None
):
    precision_values, recall_values, thresholds = (
        precision_recall_curve(
            true_labels,
            probabilities
        )
    )

    precision_values = precision_values[:-1]
    recall_values = recall_values[:-1]

    f1_values = (
        2
        * precision_values
        * recall_values
        / (
            precision_values
            + recall_values
            + 1e-12
        )
    )

    valid_mask = np.isfinite(f1_values)

    if minimum_precision is not None:
        valid_mask &= (
            precision_values
            >= minimum_precision
        )

    candidates = np.where(
        valid_mask,
        f1_values,
        -1.0
    )

    best_position = int(
        np.argmax(candidates)
    )

    return float(
        thresholds[best_position]
    )


# ------------------------------------------------
# 10. Nested group-safe OOF campaign training
# ------------------------------------------------

oof_probabilities = np.full(
    len(training_data),
    np.nan,
    dtype=np.float64
)

oof_campaign_features = None
campaign_feature_names = None
fold_metric_rows = []

total_start_time = time.perf_counter()

for outer_fold in [1, 2, 3, 4, 5]:

    print("\n" + "=" * 72)
    print(
        f"CAMPAIGN OOF TRAINING — "
        f"FOLD {outer_fold}/5"
    )
    print("=" * 72)

    fold_start_time = time.perf_counter()

    outer_holdout_positions = np.where(
        outer_folds == outer_fold
    )[0]

    outer_training_positions = np.where(
        outer_folds != outer_fold
    )[0]

    if (
        set(groups[outer_training_positions])
        & set(groups[outer_holdout_positions])
    ):
        raise ValueError(
            "Outer campaign leakage detected."
        )

    outer_training_labels = labels[
        outer_training_positions
    ]

    outer_training_groups = groups[
        outer_training_positions
    ]

    inner_splitter = StratifiedGroupKFold(
        n_splits=4,
        shuffle=True,
        random_state=SEED + outer_fold
    )

    inner_oof_features = None

    for (
        inner_reference_local,
        inner_holdout_local
    ) in inner_splitter.split(
        np.zeros(
            (
                len(outer_training_positions),
                1
            )
        ),
        outer_training_labels,
        outer_training_groups
    ):
        inner_reference_global = (
            outer_training_positions[
                inner_reference_local
            ]
        )

        inner_holdout_global = (
            outer_training_positions[
                inner_holdout_local
            ]
        )

        inner_features = (
            build_campaign_features(
                inner_reference_global,
                inner_holdout_global
            )
        )

        if inner_oof_features is None:
            campaign_feature_names = (
                inner_features.columns.tolist()
            )

            inner_oof_features = np.full(
                (
                    len(outer_training_positions),
                    len(campaign_feature_names)
                ),
                np.nan,
                dtype=np.float32
            )

        inner_oof_features[
            inner_holdout_local
        ] = inner_features[
            campaign_feature_names
        ].to_numpy(
            dtype=np.float32
        )

    if np.isnan(inner_oof_features).any():
        raise ValueError(
            "Missing inner OOF campaign features."
        )

    outer_holdout_features = (
        build_campaign_features(
            outer_training_positions,
            outer_holdout_positions
        )
    )[
        campaign_feature_names
    ].to_numpy(
        dtype=np.float32
    )

    if oof_campaign_features is None:
        oof_campaign_features = np.full(
            (
                len(training_data),
                len(campaign_feature_names)
            ),
            np.nan,
            dtype=np.float32
        )

    oof_campaign_features[
        outer_holdout_positions
    ] = outer_holdout_features

    negative_count = int(
        (outer_training_labels == 0).sum()
    )

    positive_count = int(
        (outer_training_labels == 1).sum()
    )

    positive_weight = float(
        np.sqrt(
            negative_count
            / max(positive_count, 1)
        )
    )

    campaign_model = CatBoostClassifier(
        iterations=500,
        depth=5,
        learning_rate=0.04,
        loss_function="Logloss",
        eval_metric="AUC",
        class_weights=[
            1.0,
            positive_weight
        ],
        l2_leaf_reg=8.0,
        random_strength=0.5,
        bootstrap_type="Bernoulli",
        subsample=0.85,
        random_seed=SEED + outer_fold,
        allow_writing_files=False,
        thread_count=-1,
        verbose=False
    )

    campaign_model.fit(
        inner_oof_features,
        outer_training_labels,
        verbose=False
    )

    holdout_probabilities = (
        campaign_model.predict_proba(
            outer_holdout_features
        )[:, 1]
    )

    oof_probabilities[
        outer_holdout_positions
    ] = holdout_probabilities

    fold_metrics = evaluate_scores(
        labels[outer_holdout_positions],
        holdout_probabilities,
        threshold=0.5
    )

    fold_seconds = (
        time.perf_counter()
        - fold_start_time
    )

    fold_metric_rows.append({
        "OOF_Fold": outer_fold,
        "Training_Rows": len(
            outer_training_positions
        ),
        "Holdout_Rows": len(
            outer_holdout_positions
        ),
        "Holdout_Fraudulent": int(
            labels[
                outer_holdout_positions
            ].sum()
        ),
        "Campaign_Features": len(
            campaign_feature_names
        ),
        "Positive_Class_Weight":
            positive_weight,
        "PR_AUC": fold_metrics["PR_AUC"],
        "ROC_AUC": fold_metrics["ROC_AUC"],
        "Precision_at_0_5":
            fold_metrics["Precision"],
        "Recall_at_0_5":
            fold_metrics["Recall"],
        "F1_at_0_5":
            fold_metrics["F1"],
        "MCC_at_0_5":
            fold_metrics["MCC"],
        "Training_Time_Seconds":
            fold_seconds,
        "Crossing_Campaign_Groups": 0
    })

    print(
        "Campaign features:",
        len(campaign_feature_names)
    )
    print(
        "PR-AUC:",
        round(fold_metrics["PR_AUC"], 4)
    )
    print(
        "F1 at threshold 0.5:",
        round(fold_metrics["F1"], 4)
    )
    print(
        "Fold time:",
        round(fold_seconds, 2),
        "seconds"
    )

    del (
        campaign_model,
        inner_oof_features,
        outer_holdout_features
    )

    gc.collect()

if np.isnan(oof_probabilities).any():
    raise ValueError(
        "Missing campaign OOF predictions."
    )

if np.isnan(oof_campaign_features).any():
    raise ValueError(
        "Missing campaign OOF feature values."
    )

total_training_seconds = (
    time.perf_counter()
    - total_start_time
)


# ------------------------------------------------
# 11. Pooled OOF metrics
# ------------------------------------------------

best_f1_threshold = find_best_threshold(
    labels,
    oof_probabilities
)

precision_guardrail_threshold = (
    find_best_threshold(
        labels,
        oof_probabilities,
        minimum_precision=0.90
    )
)

pooled_rows = []

for threshold_type, threshold in [
    ("Default 0.50", 0.50),
    (
        "OOF F1 Optimized",
        best_f1_threshold
    ),
    (
        "Precision >= 0.90",
        precision_guardrail_threshold
    )
]:
    metric_row = evaluate_scores(
        labels,
        oof_probabilities,
        threshold
    )

    metric_row[
        "Threshold_Type"
    ] = threshold_type

    pooled_rows.append(metric_row)

pooled_metrics = pd.DataFrame(
    pooled_rows
)[
    [
        "Threshold_Type",
        "Threshold",
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "Specificity",
        "Balanced_Accuracy",
        "PR_AUC",
        "ROC_AUC",
        "MCC",
        "TN",
        "FP",
        "FN",
        "TP"
    ]
]

fold_metrics_table = pd.DataFrame(
    fold_metric_rows
)


# ------------------------------------------------
# 12. Save Step 6 artifacts
# ------------------------------------------------

campaign_predictions = oof_manifest.copy()

campaign_predictions[
    "campaign_probability"
] = oof_probabilities

prediction_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_oof_predictions.csv"
)

feature_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_oof_features.csv"
)

fold_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_oof_fold_metrics.csv"
)

pooled_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_oof_pooled_metrics.csv"
)

configuration_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_campaign_configuration.json"
)

campaign_predictions.to_csv(
    prediction_path,
    index=False
)

campaign_feature_output = pd.DataFrame(
    oof_campaign_features,
    columns=campaign_feature_names
)

campaign_feature_output.insert(
    0,
    "source_row_index",
    training_data[
        "source_row_index"
    ].astype(int).to_numpy()
)

campaign_feature_output.to_csv(
    feature_path,
    index=False
)

fold_metrics_table.to_csv(
    fold_metrics_path,
    index=False
)

pooled_metrics.to_csv(
    pooled_metrics_path,
    index=False
)


def file_sha256(file_path):
    checksum = hashlib.sha256()

    with open(file_path, "rb") as file_handle:
        for block in iter(
            lambda: file_handle.read(
                1024 * 1024
            ),
            b""
        ):
            checksum.update(block)

    return checksum.hexdigest()


configuration = {
    "created_utc":
        datetime.now(timezone.utc).isoformat(),
    "experiment":
        "SAGE-FJD",
    "step":
        6,
    "view":
        "Fold-local campaign novelty and risk",
    "feature_count":
        len(campaign_feature_names),
    "feature_names":
        campaign_feature_names,
    "template_smoothing_strength":
        SMOOTHING_STRENGTH,
    "nested_group_safe_feature_generation":
        True,
    "classifier":
        "CatBoostClassifier",
    "iterations":
        500,
    "depth":
        5,
    "class_weight_method":
        "square_root_imbalance_ratio",
    "pooled_oof_pr_auc":
        float(
            average_precision_score(
                labels,
                oof_probabilities
            )
        ),
    "best_oof_f1_threshold":
        best_f1_threshold,
    "training_seconds":
        total_training_seconds,
    "campaign_overlap":
        0,
    "validation_rows_used":
        0,
    "test_rows_used":
        0,
    "prediction_sha256":
        file_sha256(prediction_path)
}

with open(
    configuration_path,
    "w",
    encoding="utf-8"
) as configuration_file:
    json.dump(
        configuration,
        configuration_file,
        indent=2
    )

checkpoint_zip = Path(
    shutil.make_archive(
        "/kaggle/working/"
        "sage_fjd_step_06_checkpoint",
        "zip",
        root_dir=PROJECT_DIRECTORY
    )
)


# ------------------------------------------------
# 13. Display results
# ------------------------------------------------

print("\nCAMPAIGN OOF FOLD RESULTS")
display(
    fold_metrics_table.round(4)
)

print("\nPOOLED CAMPAIGN OOF RESULTS")
display(
    pooled_metrics.round(4)
)

print("\n" + "=" * 72)
print("SAGE-FJD PROPOSED MODEL STEP 6 COMPLETED")
print("=" * 72)
print(
    "Total time:",
    round(total_training_seconds / 60, 2),
    "minutes"
)
print(
    "Pooled OOF PR-AUC:",
    round(
        average_precision_score(
            labels,
            oof_probabilities
        ),
        4
    )
)
print(
    "Best OOF F1 threshold:",
    round(best_f1_threshold, 4)
)
print(
    "Campaign features:",
    len(campaign_feature_names)
)
print("Nested group-safe generation: True")
print("Campaign overlap: 0")
print("Validation rows used: 0")
print("Test rows used: 0")
print("Predictions:", prediction_path)
print("Checkpoint ZIP:", checkpoint_zip)
print("Next step: reliability-aware OOF fusion.")
print("=" * 72)