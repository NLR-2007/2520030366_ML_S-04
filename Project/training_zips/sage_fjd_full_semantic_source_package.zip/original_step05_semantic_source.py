# ================================================================
# SAGE-FJD — STEP 5
# SECTION-AWARE MULTI-WINDOW SEMANTIC OOF BRANCH
# ================================================================

from pathlib import Path
from datetime import datetime, timezone
import gc
import hashlib
import html
import json
import shutil
import time

import numpy as np
import pandas as pd
import torch

from sentence_transformers import SentenceTransformer

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score
)

from IPython.display import display


# ------------------------------------------------
# 1. Configuration
# ------------------------------------------------

SEED = 42

np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)
    torch.set_float32_matmul_precision("high")

PROJECT_DIRECTORY = Path(
    "/kaggle/working/proposed_sage_fjd"
)

OOF_MANIFEST_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_oof_manifest.csv"
)

EMBEDDING_CACHE_PATH = (
    PROJECT_DIRECTORY
    / "sage_fjd_section_embeddings.npz"
)

MODEL_NAME = (
    "sentence-transformers/all-MiniLM-L6-v2"
)

SECTION_FIELDS = [
    "title",
    "company_profile",
    "description",
    "requirements",
    "benefits"
]

# Maximum windows retained from each section
MAX_SECTION_WINDOWS = {
    "title": 1,
    "company_profile": 3,
    "description": 5,
    "requirements": 4,
    "benefits": 3
}

WINDOW_TOKENS = 220
WINDOW_STRIDE = 180
ENCODING_BATCH_SIZE = 128
SEMANTIC_CLASSIFIER_C = 0.35

if not OOF_MANIFEST_PATH.is_file():
    raise FileNotFoundError(
        "OOF manifest was not found."
    )

if not torch.cuda.is_available():
    raise RuntimeError(
        "GPU is not enabled. Select T4 x2 "
        "in Kaggle Session options."
    )

DEVICE = "cuda:0"


# ------------------------------------------------
# 2. Locate dataset
# ------------------------------------------------

dataset_candidates = [
    Path(
        "/kaggle/input/datasets/shivamb/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    ),
    Path(
        "/kaggle/input/"
        "real-or-fake-fake-jobposting-prediction/"
        "fake_job_postings.csv"
    )
]

dataset_candidates.extend(
    Path("/kaggle/input").rglob(
        "fake_job_postings.csv"
    )
)

dataset_candidates = [
    path
    for path in dataset_candidates
    if path.is_file()
]

if not dataset_candidates:
    raise FileNotFoundError(
        "fake_job_postings.csv was not found."
    )

DATASET_PATH = dataset_candidates[0]


# ------------------------------------------------
# 3. Load and validate OOF manifest
# ------------------------------------------------

oof_manifest = pd.read_csv(
    OOF_MANIFEST_PATH
)

required_columns = [
    "source_row_index",
    "fraudulent",
    "campaign_group",
    "oof_fold",
    "source_split"
]

missing_columns = [
    column
    for column in required_columns
    if column not in oof_manifest.columns
]

if missing_columns:
    raise ValueError(
        "Missing OOF columns: "
        + ", ".join(missing_columns)
    )

if len(oof_manifest) != 12525:
    raise ValueError(
        "Expected 12,525 training rows."
    )

if int(oof_manifest["fraudulent"].sum()) != 609:
    raise ValueError(
        "Expected 609 fraudulent rows."
    )

if not (
    oof_manifest["source_split"]
    .astype(str)
    .str.lower()
    .eq("train")
    .all()
):
    raise ValueError(
        "Non-training rows exist."
    )

campaign_overlap = int(
    (
        oof_manifest
        .groupby("campaign_group")["oof_fold"]
        .nunique()
        > 1
    ).sum()
)

if campaign_overlap != 0:
    raise ValueError(
        "Campaign groups cross OOF folds."
    )


# ------------------------------------------------
# 4. Load only training text rows
# ------------------------------------------------

wanted_source_rows = set(
    oof_manifest["source_row_index"]
    .astype(int)
    .tolist()
)

retained_chunks = []
row_cursor = 0

print("=" * 72)
print("SAGE-FJD STEP 5 — SECTION-AWARE SEMANTIC BRANCH")
print("=" * 72)
print("Embedding model:", MODEL_NAME)
print("Device:", DEVICE)
print("Dataset:", DATASET_PATH)
print("Loading leakage-safe training text...")

for dataset_chunk in pd.read_csv(
    DATASET_PATH,
    usecols=SECTION_FIELDS,
    chunksize=2000
):
    chunk_rows = np.arange(
        row_cursor,
        row_cursor + len(dataset_chunk)
    )

    keep_mask = np.isin(
        chunk_rows,
        list(wanted_source_rows)
    )

    if keep_mask.any():
        retained = (
            dataset_chunk.loc[keep_mask]
            .copy()
            .reset_index(drop=True)
        )

        retained.insert(
            0,
            "source_row_index",
            chunk_rows[keep_mask]
        )

        retained_chunks.append(retained)

    row_cursor += len(dataset_chunk)

training_text = pd.concat(
    retained_chunks,
    ignore_index=True
)

del retained_chunks
gc.collect()

training_data = (
    oof_manifest
    .merge(
        training_text,
        on="source_row_index",
        how="left",
        validate="one_to_one"
    )
    .sort_values("source_row_index")
    .reset_index(drop=True)
)

if len(training_data) != 12525:
    raise ValueError(
        "Training-text count mismatch."
    )


# ------------------------------------------------
# 5. Text cleaning
# ------------------------------------------------

def clean_text(value):
    if pd.isna(value):
        return ""

    text = html.unescape(str(value))

    text = pd.Series([text]).str.replace(
        r"<[^>]+>",
        " ",
        regex=True
    ).iloc[0]

    text = " ".join(text.split())

    return text.strip()


for section in SECTION_FIELDS:
    training_data[section] = (
        training_data[section]
        .map(clean_text)
    )

print("Training rows:", len(training_data))
print(
    "Fraudulent rows:",
    int(training_data["fraudulent"].sum())
)
print("Validation/test rows retained: 0")


# ------------------------------------------------
# 6. Load sentence-transformer model
# ------------------------------------------------

embedding_start_time = time.perf_counter()

if EMBEDDING_CACHE_PATH.is_file():

    print("\nLoading cached semantic embeddings...")

    cached_data = np.load(
        EMBEDDING_CACHE_PATH
    )

    cached_source_rows = cached_data[
        "source_row_index"
    ]

    expected_source_rows = (
        training_data["source_row_index"]
        .astype(int)
        .to_numpy()
    )

    if not np.array_equal(
        cached_source_rows,
        expected_source_rows
    ):
        raise ValueError(
            "Cached embeddings do not match "
            "the current OOF manifest."
        )

    semantic_features = cached_data[
        "semantic_features"
    ].astype(np.float32)

    embedding_seconds = 0.0

    print(
        "Cached embeddings verified:",
        semantic_features.shape
    )

else:

    print("\nLoading embedding model...")

    embedding_model = SentenceTransformer(
        MODEL_NAME,
        device=DEVICE
    )

    embedding_model.max_seq_length = 256

    tokenizer = embedding_model.tokenizer

    embedding_dimension = (
        embedding_model
        .get_sentence_embedding_dimension()
    )

    print(
        "Embedding dimension:",
        embedding_dimension
    )

    print(
        "Window tokens:",
        WINDOW_TOKENS
    )

    print(
        "Window stride:",
        WINDOW_STRIDE
    )


    # ------------------------------------------------
    # 7. Create exact token windows
    # ------------------------------------------------

    def create_token_windows(
        text,
        section_name
    ):
        if not text:
            return [
                f"[EMPTY {section_name.upper()}]"
            ]

        token_ids = tokenizer(
            text,
            add_special_tokens=False,
            truncation=False
        )["input_ids"]

        if len(token_ids) <= WINDOW_TOKENS:
            return [text]

        window_starts = list(
            range(
                0,
                len(token_ids),
                WINDOW_STRIDE
            )
        )

        final_start = max(
            0,
            len(token_ids) - WINDOW_TOKENS
        )

        if final_start not in window_starts:
            window_starts.append(final_start)

        window_starts = sorted(
            set(window_starts)
        )

        maximum_windows = (
            MAX_SECTION_WINDOWS[
                section_name
            ]
        )

        if len(window_starts) > maximum_windows:
            selected_positions = (
                np.linspace(
                    0,
                    len(window_starts) - 1,
                    maximum_windows
                )
                .round()
                .astype(int)
            )

            window_starts = [
                window_starts[position]
                for position in selected_positions
            ]

        windows = []

        for start_position in window_starts:
            window_token_ids = token_ids[
                start_position:
                start_position + WINDOW_TOKENS
            ]

            decoded_window = tokenizer.decode(
                window_token_ids,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=True
            ).strip()

            if decoded_window:
                windows.append(decoded_window)

        if not windows:
            windows = [
                f"[EMPTY {section_name.upper()}]"
            ]

        return windows


    # ------------------------------------------------
    # 8. Encode and pool every section separately
    # ------------------------------------------------

    pooled_section_features = []
    normalized_section_means = []
    section_audit_rows = []

    for section_number, section_name in enumerate(
        SECTION_FIELDS,
        start=1
    ):

        print("\n" + "=" * 72)
        print(
            f"ENCODING SECTION "
            f"{section_number}/5: "
            f"{section_name}"
        )
        print("=" * 72)

        section_start_time = time.perf_counter()

        all_windows = []
        window_owners = []

        section_values = (
            training_data[section_name]
            .tolist()
        )

        for row_position, section_text in enumerate(
            section_values
        ):
            row_windows = create_token_windows(
                section_text,
                section_name
            )

            all_windows.extend(row_windows)

            window_owners.extend(
                [row_position] * len(row_windows)
            )

        window_owners = np.asarray(
            window_owners,
            dtype=np.int32
        )

        print(
            "Total windows:",
            len(all_windows)
        )

        chunk_embeddings = (
            embedding_model.encode(
                all_windows,
                batch_size=ENCODING_BATCH_SIZE,
                show_progress_bar=True,
                convert_to_numpy=True,
                normalize_embeddings=True
            )
            .astype(np.float32)
        )

        row_count = len(training_data)

        mean_pool = np.zeros(
            (
                row_count,
                embedding_dimension
            ),
            dtype=np.float32
        )

        np.add.at(
            mean_pool,
            window_owners,
            chunk_embeddings
        )

        owner_counts = np.bincount(
            window_owners,
            minlength=row_count
        ).astype(np.float32)

        mean_pool /= owner_counts[:, None]

        max_pool = np.full(
            (
                row_count,
                embedding_dimension
            ),
            -np.inf,
            dtype=np.float32
        )

        np.maximum.at(
            max_pool,
            window_owners,
            chunk_embeddings
        )

        max_pool[
            ~np.isfinite(max_pool)
        ] = 0.0

        # Normalize section mean for similarity
        mean_norms = np.linalg.norm(
            mean_pool,
            axis=1,
            keepdims=True
        )

        normalized_mean = (
            mean_pool
            / np.clip(
                mean_norms,
                1e-8,
                None
            )
        ).astype(np.float32)

        normalized_section_means.append(
            normalized_mean
        )

        # Mean + maximum chunk evidence
        section_representation = (
            np.concatenate(
                [mean_pool, max_pool],
                axis=1
            )
            .astype(np.float32)
        )

        pooled_section_features.append(
            section_representation
        )

        section_seconds = (
            time.perf_counter()
            - section_start_time
        )

        section_audit_rows.append({
            "Section": section_name,
            "Rows": row_count,
            "Windows": len(all_windows),
            "Mean_Windows_Per_Row": (
                len(all_windows) / row_count
            ),
            "Maximum_Allowed_Windows":
                MAX_SECTION_WINDOWS[
                    section_name
                ],
            "Encoding_Time_Seconds":
                section_seconds
        })

        print(
            "Completed in:",
            round(section_seconds / 60, 2),
            "minutes"
        )

        del (
            all_windows,
            window_owners,
            chunk_embeddings,
            mean_pool,
            max_pool,
            section_representation
        )

        gc.collect()
        torch.cuda.empty_cache()


    # ------------------------------------------------
    # 9. Add cross-section consistency features
    # ------------------------------------------------

    similarity_features = []
    similarity_names = []

    for first_index in range(
        len(SECTION_FIELDS)
    ):
        for second_index in range(
            first_index + 1,
            len(SECTION_FIELDS)
        ):
            cosine_similarity = np.sum(
                normalized_section_means[
                    first_index
                ]
                * normalized_section_means[
                    second_index
                ],
                axis=1,
                keepdims=True
            ).astype(np.float32)

            similarity_features.append(
                cosine_similarity
            )

            similarity_names.append(
                SECTION_FIELDS[first_index]
                + "_vs_"
                + SECTION_FIELDS[second_index]
                + "_cosine"
            )

    semantic_features = np.concatenate(
        pooled_section_features
        + similarity_features,
        axis=1
    ).astype(np.float32)

    if semantic_features.shape[0] != 12525:
        raise ValueError(
            "Semantic feature row mismatch."
        )

    expected_feature_count = (
        len(SECTION_FIELDS)
        * embedding_dimension
        * 2
        + len(similarity_features)
    )

    if (
        semantic_features.shape[1]
        != expected_feature_count
    ):
        raise ValueError(
            "Semantic feature-column mismatch."
        )

    np.savez_compressed(
        EMBEDDING_CACHE_PATH,
        source_row_index=(
            training_data[
                "source_row_index"
            ]
            .astype(int)
            .to_numpy()
        ),
        semantic_features=semantic_features
    )

    section_audit = pd.DataFrame(
        section_audit_rows
    )

    section_audit.to_csv(
        PROJECT_DIRECTORY
        / "sage_fjd_semantic_section_audit.csv",
        index=False
    )

    embedding_seconds = (
        time.perf_counter()
        - embedding_start_time
    )

    print("\nSemantic feature shape:", semantic_features.shape)
    print(
        "Embedding time:",
        round(embedding_seconds / 60, 2),
        "minutes"
    )

    del (
        embedding_model,
        tokenizer,
        pooled_section_features,
        normalized_section_means,
        similarity_features
    )

    gc.collect()
    torch.cuda.empty_cache()


# ------------------------------------------------
# 10. Metric helpers
# ------------------------------------------------

def evaluate_scores(
    labels,
    probabilities,
    threshold
):
    predictions = (
        probabilities >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        labels,
        predictions,
        labels=[0, 1]
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "Threshold": float(threshold),
        "Accuracy": accuracy_score(
            labels,
            predictions
        ),
        "Precision": precision_score(
            labels,
            predictions,
            zero_division=0
        ),
        "Recall": recall_score(
            labels,
            predictions,
            zero_division=0
        ),
        "F1": f1_score(
            labels,
            predictions,
            zero_division=0
        ),
        "Specificity": specificity,
        "Balanced_Accuracy":
            balanced_accuracy_score(
                labels,
                predictions
            ),
        "PR_AUC": average_precision_score(
            labels,
            probabilities
        ),
        "ROC_AUC": roc_auc_score(
            labels,
            probabilities
        ),
        "MCC": matthews_corrcoef(
            labels,
            predictions
        ),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp)
    }


def find_best_threshold(
    labels,
    probabilities,
    minimum_precision=None
):
    precision_values, recall_values, thresholds = (
        precision_recall_curve(
            labels,
            probabilities
        )
    )

    precision_values = precision_values[:-1]
    recall_values = recall_values[:-1]

    f1_values = (
        2
        * precision_values
        * recall_values
        / (
            precision_values
            + recall_values
            + 1e-12
        )
    )

    valid_mask = np.isfinite(f1_values)

    if minimum_precision is not None:
        valid_mask &= (
            precision_values
            >= minimum_precision
        )

    candidate_values = np.where(
        valid_mask,
        f1_values,
        -1.0
    )

    best_position = int(
        np.argmax(candidate_values)
    )

    return float(
        thresholds[best_position]
    )


# ------------------------------------------------
# 11. Five group-isolated semantic OOF models
# ------------------------------------------------

labels = (
    training_data["fraudulent"]
    .astype(int)
    .to_numpy()
)

fold_assignments = (
    training_data["oof_fold"]
    .astype(int)
    .to_numpy()
)

campaign_groups = (
    training_data["campaign_group"]
    .astype(str)
    .to_numpy()
)

oof_probabilities = np.full(
    len(training_data),
    np.nan,
    dtype=np.float64
)

fold_metric_rows = []

classification_start_time = (
    time.perf_counter()
)

for fold_number in [1, 2, 3, 4, 5]:

    print("\n" + "=" * 72)
    print(
        f"SEMANTIC OOF TRAINING — "
        f"FOLD {fold_number}/5"
    )
    print("=" * 72)

    fold_start_time = time.perf_counter()

    holdout_mask = (
        fold_assignments == fold_number
    )

    training_mask = ~holdout_mask

    if (
        set(campaign_groups[training_mask])
        & set(campaign_groups[holdout_mask])
    ):
        raise ValueError(
            "Campaign leakage detected."
        )

    training_labels = labels[
        training_mask
    ]

    negative_count = int(
        (training_labels == 0).sum()
    )

    positive_count = int(
        (training_labels == 1).sum()
    )

    positive_weight = float(
        np.sqrt(
            negative_count
            / max(positive_count, 1)
        )
    )

    semantic_classifier = LogisticRegression(
        C=SEMANTIC_CLASSIFIER_C,
        penalty="l2",
        solver="liblinear",
        class_weight={
            0: 1.0,
            1: positive_weight
        },
        max_iter=2000,
        random_state=SEED + fold_number
    )

    semantic_classifier.fit(
        semantic_features[training_mask],
        labels[training_mask]
    )

    holdout_probabilities = (
        semantic_classifier.predict_proba(
            semantic_features[holdout_mask]
        )[:, 1]
    )

    oof_probabilities[
        holdout_mask
    ] = holdout_probabilities

    fold_metrics = evaluate_scores(
        labels[holdout_mask],
        holdout_probabilities,
        threshold=0.5
    )

    fold_seconds = (
        time.perf_counter()
        - fold_start_time
    )

    fold_metric_rows.append({
        "OOF_Fold": fold_number,
        "Training_Rows": int(
            training_mask.sum()
        ),
        "Holdout_Rows": int(
            holdout_mask.sum()
        ),
        "Holdout_Fraudulent": int(
            labels[holdout_mask].sum()
        ),
        "Semantic_Features": int(
            semantic_features.shape[1]
        ),
        "Positive_Class_Weight":
            positive_weight,
        "PR_AUC": fold_metrics["PR_AUC"],
        "ROC_AUC": fold_metrics["ROC_AUC"],
        "Precision_at_0_5":
            fold_metrics["Precision"],
        "Recall_at_0_5":
            fold_metrics["Recall"],
        "F1_at_0_5":
            fold_metrics["F1"],
        "MCC_at_0_5":
            fold_metrics["MCC"],
        "Training_Time_Seconds":
            fold_seconds,
        "Crossing_Campaign_Groups": 0
    })

    print(
        "PR-AUC:",
        round(fold_metrics["PR_AUC"], 4)
    )
    print(
        "F1 at threshold 0.5:",
        round(fold_metrics["F1"], 4)
    )
    print(
        "Fold time:",
        round(fold_seconds, 2),
        "seconds"
    )

    del semantic_classifier
    gc.collect()

if np.isnan(oof_probabilities).any():
    raise ValueError(
        "Missing semantic OOF predictions."
    )

classification_seconds = (
    time.perf_counter()
    - classification_start_time
)


# ------------------------------------------------
# 12. Pooled semantic metrics
# ------------------------------------------------

best_f1_threshold = find_best_threshold(
    labels,
    oof_probabilities
)

precision_guardrail_threshold = (
    find_best_threshold(
        labels,
        oof_probabilities,
        minimum_precision=0.90
    )
)

pooled_rows = []

for threshold_type, threshold in [
    ("Default 0.50", 0.50),
    (
        "OOF F1 Optimized",
        best_f1_threshold
    ),
    (
        "Precision >= 0.90",
        precision_guardrail_threshold
    )
]:
    metric_row = evaluate_scores(
        labels,
        oof_probabilities,
        threshold
    )

    metric_row[
        "Threshold_Type"
    ] = threshold_type

    pooled_rows.append(metric_row)

pooled_metrics = pd.DataFrame(
    pooled_rows
)[
    [
        "Threshold_Type",
        "Threshold",
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "Specificity",
        "Balanced_Accuracy",
        "PR_AUC",
        "ROC_AUC",
        "MCC",
        "TN",
        "FP",
        "FN",
        "TP"
    ]
]

fold_metrics_table = pd.DataFrame(
    fold_metric_rows
)


# ------------------------------------------------
# 13. Save Step 5 artifacts
# ------------------------------------------------

semantic_predictions = oof_manifest.copy()

semantic_predictions[
    "semantic_probability"
] = oof_probabilities

prediction_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_semantic_oof_predictions.csv"
)

fold_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_semantic_oof_fold_metrics.csv"
)

pooled_metrics_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_semantic_oof_pooled_metrics.csv"
)

configuration_path = (
    PROJECT_DIRECTORY
    / "sage_fjd_semantic_configuration.json"
)

semantic_predictions.to_csv(
    prediction_path,
    index=False
)

fold_metrics_table.to_csv(
    fold_metrics_path,
    index=False
)

pooled_metrics.to_csv(
    pooled_metrics_path,
    index=False
)


def file_sha256(file_path):
    checksum = hashlib.sha256()

    with open(file_path, "rb") as file_handle:
        for block in iter(
            lambda: file_handle.read(
                1024 * 1024
            ),
            b""
        ):
            checksum.update(block)

    return checksum.hexdigest()


configuration = {
    "created_utc":
        datetime.now(timezone.utc).isoformat(),
    "experiment":
        "SAGE-FJD",
    "step":
        5,
    "view":
        "Section-aware semantic",
    "embedding_model":
        MODEL_NAME,
    "section_fields":
        SECTION_FIELDS,
    "window_tokens":
        WINDOW_TOKENS,
    "window_stride":
        WINDOW_STRIDE,
    "maximum_section_windows":
        MAX_SECTION_WINDOWS,
    "pooling":
        [
            "section_chunk_mean",
            "section_chunk_max",
            "cross_section_cosine"
        ],
    "semantic_feature_count":
        int(semantic_features.shape[1]),
    "classifier":
        "LogisticRegression",
    "classifier_c":
        SEMANTIC_CLASSIFIER_C,
    "class_weight_method":
        "square_root_imbalance_ratio",
    "embedding_seconds":
        embedding_seconds,
    "classification_seconds":
        classification_seconds,
    "pooled_oof_pr_auc":
        float(
            average_precision_score(
                labels,
                oof_probabilities
            )
        ),
    "best_oof_f1_threshold":
        best_f1_threshold,
    "campaign_overlap":
        0,
    "validation_rows_used":
        0,
    "test_rows_used":
        0,
    "prediction_sha256":
        file_sha256(prediction_path)
}

with open(
    configuration_path,
    "w",
    encoding="utf-8"
) as configuration_file:
    json.dump(
        configuration,
        configuration_file,
        indent=2
    )

checkpoint_zip = Path(
    shutil.make_archive(
        "/kaggle/working/"
        "sage_fjd_step_05_checkpoint",
        "zip",
        root_dir=PROJECT_DIRECTORY
    )
)


# ------------------------------------------------
# 14. Display results
# ------------------------------------------------

print("\nSEMANTIC OOF FOLD RESULTS")
display(
    fold_metrics_table.round(4)
)

print("\nPOOLED SEMANTIC OOF RESULTS")
display(
    pooled_metrics.round(4)
)

print("\n" + "=" * 72)
print("SAGE-FJD PROPOSED MODEL STEP 5 COMPLETED")
print("=" * 72)
print(
    "Embedding time:",
    round(embedding_seconds / 60, 2),
    "minutes"
)
print(
    "Classification time:",
    round(classification_seconds / 60, 2),
    "minutes"
)
print(
    "Pooled OOF PR-AUC:",
    round(
        average_precision_score(
            labels,
            oof_probabilities
        ),
        4
    )
)
print(
    "Best OOF F1 threshold:",
    round(best_f1_threshold, 4)
)
print(
    "Semantic features:",
    semantic_features.shape[1]
)
print("Campaign overlap: 0")
print("Validation rows used: 0")
print("Test rows used: 0")
print("Predictions:", prediction_path)
print("Checkpoint ZIP:", checkpoint_zip)
print("Next step: campaign novelty OOF branch.")
print("=" * 72)