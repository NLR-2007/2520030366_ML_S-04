# ================================================================

from pathlib import Path
import ast
import hashlib
import json
import re
import zipfile


print("=" * 72)
print("STEP 9D-P0 — EXPORT COMPLETE STEP-6 CAMPAIGN SOURCE")
print("=" * 72)

WORKING_ROOT = Path("/kaggle/working")
PROJECT_ROOT = WORKING_ROOT / "proposed_sage_fjd"
RECOVERY_ROOT = PROJECT_ROOT / "campaign_source_recovery"
EXPORT_ROOT = RECOVERY_ROOT / "full_source_export"

EXPORT_ROOT.mkdir(parents=True, exist_ok=True)

OUTPUT_ZIP = (
    WORKING_ROOT
    / "sage_fjd_full_campaign_source_package.zip"
)

MARKER_GROUPS = [
    ["SAGE-FJD — STEP 6", "SAGE-FJD STEP 6"],
    ["CAMPAIGN NOVELTY/RISK", "CAMPAIGN NOVELTY", "CAMPAIGN RISK"],
    ["CatBoostClassifier("],
    ["campaign_group"],
    ["campaign_features"],
    ["oof_fold"],
    ["source_row_index"],
    ["Positive_Class_Weight", "positive_weight"],
    ["Campaign_Features", "campaign feature"],
    ["sage_fjd_campaign_configuration"],
]

CORE_MARKERS = [
    "CatBoostClassifier(",
    "campaign_group",
    "source_row_index",
]


def sha256_text(text):
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def marker_results(text):
    lowered_text = text.lower()
    results = []

    for marker_group in MARKER_GROUPS:
        matched = any(
            marker.lower() in lowered_text
            for marker in marker_group
        )
        results.append(matched)

    return results


def syntax_is_valid(text):
    try:
        ast.parse(text)
        return True
    except SyntaxError:
        return False


candidates = []
seen_hashes = set()


def add_candidate(text, origin, candidate_type):
    if not text or len(text) < 2000:
        return

    lowered_text = text.lower()

    if not all(
        marker.lower() in lowered_text
        for marker in CORE_MARKERS
    ):
        return

    source_sha256 = sha256_text(text)

    if source_sha256 in seen_hashes:
        return

    seen_hashes.add(source_sha256)

    markers = marker_results(text)
    line_count = len(text.splitlines())
    syntax_valid = syntax_is_valid(text)
    origin_lower = origin.lower()

    header_position = min(
        [
            position
            for marker in MARKER_GROUPS[0]
            if (
                position := lowered_text.find(
                    marker.lower()
                )
            ) >= 0
        ]
        or [10**9]
    )

    header_early = header_position < 1500
    relevant_filename = any(
        token in origin_lower
        for token in [
            "step06",
            "step_06",
            "step6",
            "campaign",
        ]
    )
    plausible_size = 400 <= line_count <= 3000

    score = (
        sum(markers) * 100
        + int(syntax_valid) * 80
        + int(header_early) * 60
        + int(relevant_filename) * 40
        + int(plausible_size) * 25
        + int(candidate_type == "isolated_block") * 30
    )

    candidates.append({
        "origin": origin,
        "candidate_type": candidate_type,
        "text": text,
        "sha256": source_sha256,
        "line_count": line_count,
        "syntax_valid": syntax_valid,
        "markers_found": sum(markers),
        "marker_results": markers,
        "header_early": header_early,
        "score": score,
    })


def add_source_variants(text, origin):
    add_candidate(text, origin, "complete_file")

    # Jupytext / virtual-document cell blocks.
    cell_parts = re.split(
        r"(?m)^#\s*%%.*$|^#\s*In\[[^]]*\]:\s*$",
        text,
    )

    for part_number, part in enumerate(cell_parts):
        add_candidate(
            part,
            f"{origin}::cell_{part_number}",
            "isolated_cell",
        )

    # Isolate a Step-6 block from a larger notebook export.
    header_pattern = re.compile(
        r"SAGE-FJD\s*(?:—|-)\s*STEP\s*6\b",
        flags=re.IGNORECASE,
    )

    next_step_pattern = re.compile(
        r"(?m)^#\s*=+\s*$\n"
        r"#\s*SAGE-FJD\s*(?:—|-)\s*STEP\s*(?!6\b)\d+",
        flags=re.IGNORECASE,
    )

    for match_number, header_match in enumerate(
        header_pattern.finditer(text)
    ):
        start = text.rfind(
            "# ================================================================",
            0,
            header_match.start(),
        )

        if start < 0:
            start = max(0, header_match.start() - 200)

        next_match = next_step_pattern.search(
            text,
            header_match.end(),
        )

        end = (
            next_match.start()
            if next_match is not None
            else len(text)
        )

        block = text[start:end].strip() + "\n"

        add_candidate(
            block,
            f"{origin}::step6_block_{match_number}",
            "isolated_block",
        )


# ------------------------------------------------
# 1. Inspect source files and virtual documents
# ------------------------------------------------

search_roots = [
    PROJECT_ROOT,
    WORKING_ROOT / ".virtual_documents",
]

for search_root in search_roots:
    if not search_root.exists():
        continue

    for source_path in search_root.rglob("*"):
        if not source_path.is_file():
            continue

        if source_path.suffix.lower() not in {
            ".py",
            ".txt",
        }:
            continue

        if source_path.stat().st_size > 10_000_000:
            continue

        try:
            source_text = source_path.read_text(
                encoding="utf-8"
            )
        except (UnicodeDecodeError, OSError):
            continue

        add_source_variants(
            source_text,
            str(source_path),
        )


# ------------------------------------------------
# 2. Inspect current IPython input history
# ------------------------------------------------

try:
    input_history = get_ipython().user_ns.get(
        "In",
        [],
    )
except NameError:
    input_history = []

for history_index, history_source in enumerate(
    input_history
):
    if isinstance(history_source, str):
        add_source_variants(
            history_source,
            f"IPython_In[{history_index}]",
        )


# ------------------------------------------------
# 3. Inspect notebook code cells
# ------------------------------------------------

for notebook_path in WORKING_ROOT.rglob("*.ipynb"):
    try:
        notebook_data = json.loads(
            notebook_path.read_text(encoding="utf-8")
        )
    except (json.JSONDecodeError, OSError):
        continue

    for cell_number, cell in enumerate(
        notebook_data.get("cells", [])
    ):
        if cell.get("cell_type") != "code":
            continue

        cell_source = "".join(
            cell.get("source", [])
        )

        add_source_variants(
            cell_source,
            f"{notebook_path}::cell_{cell_number}",
        )


# ------------------------------------------------
# 4. Inspect Step-6 checkpoint ZIP source members
# ------------------------------------------------

step06_zip_paths = sorted({
    *WORKING_ROOT.rglob("*step*06*.zip"),
    *WORKING_ROOT.rglob("*step_6*.zip"),
})

zip_member_report = []

for zip_path in step06_zip_paths:
    try:
        with zipfile.ZipFile(zip_path, "r") as archive:
            for member_info in archive.infolist():
                zip_member_report.append({
                    "zip": str(zip_path),
                    "member": member_info.filename,
                    "size_bytes": member_info.file_size,
                })

                member_suffix = Path(
                    member_info.filename
                ).suffix.lower()

                if member_suffix not in {".py", ".txt"}:
                    continue

                try:
                    member_text = archive.read(
                        member_info.filename
                    ).decode("utf-8")
                except (UnicodeDecodeError, KeyError):
                    continue

                add_source_variants(
                    member_text,
                    f"{zip_path}::{member_info.filename}",
                )
    except (zipfile.BadZipFile, OSError):
        continue


# ------------------------------------------------
# 5. Select and verify the best complete source
# ------------------------------------------------

ranked_candidates = sorted(
    candidates,
    key=lambda item: (
        item["score"],
        item["markers_found"],
        item["syntax_valid"],
        -abs(item["line_count"] - 1300),
    ),
    reverse=True,
)

candidate_summary = [
    {
        key: candidate[key]
        for key in [
            "origin",
            "candidate_type",
            "sha256",
            "line_count",
            "syntax_valid",
            "markers_found",
            "marker_results",
            "header_early",
            "score",
        ]
    }
    for candidate in ranked_candidates
]

summary_path = EXPORT_ROOT / "candidate_summary.json"
summary_path.write_text(
    json.dumps(candidate_summary, indent=2),
    encoding="utf-8",
)

zip_report_path = (
    EXPORT_ROOT
    / "step06_checkpoint_member_report.json"
)

zip_report_path.write_text(
    json.dumps(zip_member_report, indent=2),
    encoding="utf-8",
)

valid_candidates = [
    candidate
    for candidate in ranked_candidates
    if candidate["syntax_valid"]
    and candidate["markers_found"] >= 8
    and candidate["line_count"] >= 400
]

if not valid_candidates:
    print("Complete Step-6 source found: False")
    print("Candidates inspected:", len(candidates))
    print("Diagnostic:", summary_path)
    print("No model training was performed.")
    print("Validation labels loaded: False")
    print("Test rows used: 0")
    raise RuntimeError(
        "Complete Step-6 source was not recovered. "
        "Download the current Kaggle notebook as .ipynb "
        "and upload it before campaign training."
    )

selected = valid_candidates[0]

full_source_path = (
    EXPORT_ROOT
    / "original_step06_campaign_source.py"
)

full_source_path.write_text(
    selected["text"],
    encoding="utf-8",
)

ast.parse(
    full_source_path.read_text(encoding="utf-8")
)

manifest = {
    "selected_origin": selected["origin"],
    "candidate_type": selected["candidate_type"],
    "source_file": str(full_source_path),
    "source_sha256": selected["sha256"],
    "line_count": selected["line_count"],
    "markers_found": selected["markers_found"],
    "markers_expected": len(MARKER_GROUPS),
    "marker_results": selected["marker_results"],
    "syntax_valid": True,
    "validation_labels_loaded": False,
    "test_rows_used": 0,
    "model_training_performed": False,
}

manifest_path = EXPORT_ROOT / "source_manifest.json"
manifest_path.write_text(
    json.dumps(manifest, indent=2),
    encoding="utf-8",
)


# ------------------------------------------------
# 6. Add relevant Step-6 configuration artifacts
# ------------------------------------------------

supporting_paths = []

for pattern in [
    "*campaign*configuration*.json",
    "*campaign*feature*manifest*.csv",
    "*campaign*fold*metrics*.csv",
    "*campaign*pooled*metrics*.csv",
    "*campaign*oof*predictions*.csv",
]:
    for supporting_path in PROJECT_ROOT.rglob(pattern):
        if (
            supporting_path.is_file()
            and supporting_path.stat().st_size
            <= 2_000_000
        ):
            supporting_paths.append(supporting_path)

supporting_paths = sorted(set(supporting_paths))


# ------------------------------------------------
# 7. Package everything for inspection
# ------------------------------------------------

with zipfile.ZipFile(
    OUTPUT_ZIP,
    mode="w",
    compression=zipfile.ZIP_DEFLATED,
) as output_archive:
    output_archive.write(
        full_source_path,
        arcname=full_source_path.name,
    )
    output_archive.write(
        manifest_path,
        arcname=manifest_path.name,
    )
    output_archive.write(
        summary_path,
        arcname=summary_path.name,
    )
    output_archive.write(
        zip_report_path,
        arcname=zip_report_path.name,
    )

    used_archive_names = {
        full_source_path.name,
        manifest_path.name,
        summary_path.name,
        zip_report_path.name,
    }

    for supporting_path in supporting_paths:
        archive_name = supporting_path.name

        if archive_name in used_archive_names:
            archive_name = (
                supporting_path.parent.name
                + "__"
                + archive_name
            )

        used_archive_names.add(archive_name)

        output_archive.write(
            supporting_path,
            arcname=archive_name,
        )


print("Complete Step-6 source found: True")
print("Selected origin:", selected["origin"])
print("Candidate type:", selected["candidate_type"])
print("Source lines:", selected["line_count"])
print("Source SHA256:", selected["sha256"])
print(
    "Required markers:",
    f"{selected['markers_found']}/{len(MARKER_GROUPS)}",
)
print("Syntax valid: True")
print("Supporting artifacts:", len(supporting_paths))
print("Model training performed: False")
print("Validation labels loaded: False")
print("Test rows used: 0")
print("\nDownload:", OUTPUT_ZIP)
print("=" * 72)
