EMSCAD CLASSICAL BASELINE CHECKPOINT

Dataset:
EMSCAD fake_job_postings.csv
17,880 job postings
Target: fraudulent

Completed models:
1. Word TF-IDF + Logistic Regression
2. Word TF-IDF + Linear SVM
3. Word TF-IDF + Multinomial Naive Bayes
4. Metadata CatBoost
5. Character TF-IDF + Linear SVM
6. Hybrid Word + Character TF-IDF + Linear SVM

Evaluation protocols:
1. Standard stratified split
2. Leakage-safe campaign-disjoint split

Important:
- Both test sets remain untouched.
- This checkpoint contains metrics, configurations,
  validation predictions, feature tables and split assignments.
- Large trained model/vectorizer files are excluded.